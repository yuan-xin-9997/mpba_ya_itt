# -*- coding: utf-8 -*-
"""
Created on Wed Jul  1 12:24:37 2020

@author: AtticusYuan
"""

'''
=本代码为使用Python调用Gurobi求解PDPTW问题（Li & Lim's benchmark）
=模型参考：Parragh, S.N., Doerner, K.F. & Hartl, R.F. A survey on pickup and delivery problems .Journal für Betriebswirtschaft58,81–117 (2008)
=为了模型需要，虚拟增加了一个供车辆返回的depot，该depot只是序号不一样
=本模型，只考虑了车辆的行驶成本
'''

from gurobipy import *
import numpy as np
import pandas as pd
import math
import random
import time


def read_txt_data(DataPath):
    """读取数据.

    具体描述：读取Li & Lim's PDPTW benchmark 的txt文件格式的数据.
    """
    
    # 读取车辆信息
    VehiclesInfo=pd.read_table(DataPath,nrows=1,names=['K','C','S'])
    #print('VehiclesInfo:')
    #print(VehiclesInfo)
    Vehicles={}
    for i in range(VehiclesInfo.iloc[0,0]):
        Vehicles[i]=[VehiclesInfo.iloc[0,1],VehiclesInfo.iloc[0,2]] # 键i=车辆的序号，值为[车辆容量、速度]
    #print(Vehicles)
    
    # 读取Depot和任务信息
    ColumnNames=['TaskNo','X','Y','Demand','ET','LT','ST','PI','DI']
    TaskData=pd.read_table(DataPath,skiprows=[0],names=ColumnNames,index_col='TaskNo')
    #print('TaskData:')
    #print(TaskData)
    
    # 提取Depot和取送货点（Customer）的位置坐标 Locations
    nrows=TaskData.shape[0]
    Locations={}
    for i in range(nrows):
        if i not in Locations.keys(): 
            Locations[i]=[TaskData.iloc[i,0],TaskData.iloc[i,1]] # 键为depot或客户编号，值为相应的坐标（x，y）
    #print('Locations:',Locations)
    
    # 提取Depot和取送货点的Demand
    Demand={}
    for i in range(nrows):
        if i not in Demand.keys(): 
            Demand[i]=TaskData.iloc[i,2]
    #print('Demand',Demand)
    
    # 提取Depot和取送货点的最早和最晚取送货时间及时间窗
    TimeWindow={}
    EarliestTime=TaskData.sort_values(by='ET').iloc[0,3]
    LatestTime=TaskData.sort_values(by='LT',ascending=False).iloc[0,4]
    for i in range(nrows):
        if i not in TimeWindow.keys(): 
            TimeWindow[i]=[TaskData.iloc[i,3],TaskData.iloc[i,4]]
    # print('TimeWindow',TimeWindow)
    # print('EarliestTime:',EarliestTime)
    # print('LatestTime:',LatestTime)
    
    # 提取Depot和取送货点的服务时间ServiceTime
    ServiceTime={}
    for i in range(nrows):
        if i not in ServiceTime.keys(): 
            ServiceTime[i]=TaskData.iloc[i,5]
    #print('ServiceTime',ServiceTime)
    
    # 提取运输Request
    # 对于取货任务，PICKUP索引为0，而同一行的DELIVERY索引给出相应送货任务的索引
    Request={}
    count = 0 # 记录运输需求的数量
    for i in range(1,nrows-1):
        if TaskData.iloc[i,6] == 0:
            Request[count]=[i,TaskData.iloc[i,7]]   # 将取送货点组合在一起，键为count，值为[取货点，送货点]
            count += 1
    #print('Request:')
    #print(Request)
    
    return Vehicles,Locations,Demand,TimeWindow,ServiceTime,Request,nrows,EarliestTime,LatestTime


def make_data(n):
    """制造数据.

    具体描述：…….
    """
    # V = range(1,n+1)    # Number of vertices:n
    V = range(0,n)    # Number of vertices:n
    x = dict([(i,random.random()) for i in V]) # X coordinates of vertices i
    y = dict([(i,random.random()) for i in V]) # Y coordinates of vertices i
    c = {} # Cost matrix
    q = {} # Demnad
    Q = 100 # Vehilce capacity
    for i in V:
        q[i] = random.randint(10,20) # Demand of vertices i
        for j in V:
            if j > i: # Avoid redundant
                c[i,j] = distance(x[i],y[i],x[j],y[j]) # Complete undirected graph
    return V,c,q,Q


def calculate_euclid_distance(x1, y1, x2, y2):
    """  计算Euclid距离.

    具体描述：计算两点(x1, y1), (x2, y2)之间的Euclid距离.
    """
    EuclidDistance = math.sqrt((x2-x1)**2 + (y2-y1)**2)
    return EuclidDistance


def construct_distance_matrix(Locations):
    """  构造距离矩阵.

    具体描述：计算两点(x1, y1), (x2, y2)之间的Euclid距离.
    """
    # 构建距离矩阵
    DistanceMatrix = {}
    for i in Locations.keys():
        for j in Locations.keys():
                if i != j:
                    DistanceMatrix[i, j] = calculate_euclid_distance(Locations[i][0], Locations[i][1], 
                                                                     Locations[j][0], Locations[j][1])
    # print('DistanceMatrix:')
    # print(DistanceMatrix)
            
    # 尝试获取字典DistanceMatrix中最大的值
    key=max(DistanceMatrix, key=DistanceMatrix.get)
    LongestDistance=DistanceMatrix[key]
    # 以下尝试获取字典DistanceMatrix中最大的值（自己想的，没有用）
    # SortedDistanceMatrix=sorted(DistanceMatrix.items(), key=lambda kv:(kv[1], kv[0]),reverse=True)
    # i=0
    # for key,value in SortedDistanceMatrix.items():
    #     while i<1:
    #         LongestDistance=value
    #     i+=1
    # print('LongestDistance:',LongestDistance)
    
    return DistanceMatrix,LongestDistance


def construct_time_matrix(Vehilces,DistanceMatrix):
    """  构造通行时间矩阵.

    具体描述：对于车辆k，若其速度为sk，点i到点j的距离为dij，那么其从点i行驶到点j所用的时间tijk=dij/sk
    """
    TimeMatrix={}
    for k in range(len(Vehilces)):
        for i in Locations.keys():
            for j in Locations.keys():
                if i != j:
                    TimeMatrix[i, j, k] = DistanceMatrix[i, j] / Vehilces[k][1]
        
    return TimeMatrix


def build_pdptw_model(Vehicles,Locations,Demand,TimeWindow,ServiceTime,Request,nrows,EarliestTime,LatestTime,DistanceMatrix,LongestDistance,TimeMatrix):
    """  建立pdptw问题的模型.

    具体描述：计算两点(x1, y1), (x2, y2)之间的Euclid距离.
    """
    
    # 创建模型
    model = Model()
    
    '''
    ## 创建变量方式1
    for k in Vehicles.keys():
        for i in range(nrows):
            q[i,k] = model.addVar(ub=Vehicles[k][0],vtype=GRB.INTEGER, name="q(%s,%s)" % (i,k)) # 变量q_{ik}
            b[i,k] = model.addVar(lb=TimeWindow[i][0],ub=TimeWindow[i][1],vtype=GRB.CONTINUOUS, name="b(%s,%s)" % (i,k)) # # 变量b_{ik}
            for j in range(nrows):
                if i != j:              
                    x[i,j,k] = model.addVar(vtype=GRB.BINARY, name="x(%s,%s,%s)" % (i,j,k)) # # 变量x_{ijk}
    '''
    
    ## 创建变量方式2
    
    # 变量下标存放字典
    xindex = {}     # 存储变量xijk的下标ijk，表示车辆k是否经过弧ij
    qindex = {}     # 存储变量qik的下标ik，表示车辆k即将离开i时的载货量
    bindex = {}     # 存储变量bik的下标ik，表示车辆k开始服务i的时间
    
    for k in Vehicles.keys():
        for i in range(nrows):
            qindex[i,k] = 0
            bindex[i,k] = 0
            for j in range(nrows):
                if i != j:
                    xindex[i,j,k] = 0
    
    x = model.addVars(xindex.keys(), vtype=GRB.BINARY, name='x')  # 变量x_{ijk}
    q = model.addVars(qindex.keys(), vtype=GRB.INTEGER, name='q')  # 变量q_{ik}
    b = model.addVars(bindex.keys(), vtype=GRB.CONTINUOUS, name='b')  # 变量b_{ik}
    
    ## ================== VRPTW===================
    
    # 约束（1）every vertex has to be served exactly once，除了depot外，每个节点只被服务一次
    for i in range(1, nrows-1):
        model.addConstr(x.sum(i,'*','*') == 1)  # 星号*的用法
    
    # 约束(2-3) guarantee that every vehicle starts at the depot and returns to the depot 
    # at the end of its route. 每辆车必须从depot出发，最后回到depot
    # 约束(4) Flow conservation 流平衡约束
    for k in Vehicles.keys():
        model.addConstr(x.sum(0,'*',k) == 1)       # 车辆k从depot出发
        model.addConstr(x.sum('*',nrows-1,k) == 1)       # 车辆k回到depot
        for i in range(1, nrows-1):                              # 车辆k在P和D的流平衡约束
            model.addConstr(x.sum(i,'*',k) == x.sum('*',i,k))
            
    # 约束 (5) Time variables are used to eliminate subtours,用时间变量来消除子回路约束
    # 需要用大M法来线性化该约束，M定义为 2*(LatestTime+LongestDistance)
    for i in xindex.keys():
        model.addConstr(b[i[1],i[2]] + 2 * (1 - x[i]) * (LatestTime+LongestDistance) >=
                        b[i[0],i[2]] + ServiceTime[i[0]] + TimeMatrix[i])
    
    # 约束(6-7) guarantee that a vehicle’s capacity is not exceeded throughout its tour，载货量平衡与车辆载量约束
    # 约束(6) 载货量平衡约束，需要用大M法来线性化该约束，M定义为 100*车辆最大载量
    for i in xindex.keys():
        model.addConstr(q[i[1],i[2]] + (1- x[i]) * (100*Vehicles[i[2]][0])>=
                        q[i[0],i[2]]+Demand[i[1]])
    
    # 约束（7）车辆载量约束
    for i in qindex.keys():
        model.addConstr(q[i]>=0)
        model.addConstr(q[i]>=Demand[i[0]])
        model.addConstr(q[i]<=Vehicles[i[1]][0])
        model.addConstr(q[i]<=Vehicles[i[1]][0]+Demand[i[0]])
    
    # 约束（8）depot和customer的时间窗约束
    '''
    # 按三引号内部的方式写，会导致错误KeyError: (0, 0)
    for i in bindex.keys():
        model.addConstr(b[i] >= TimeWindow[i][0])
        model.addConstr(b[i] <= TimeWindow[i][1])
    '''
    '''
    # 按三引号内部的方式写，会导致错误KeyError: 0
    for i in range(len(bindex)):
        model.addConstr(b[i] >= TimeWindow[i][0])
        model.addConstr(b[i] <= TimeWindow[i][1])
    '''
    for i in range(len(Vehicles)):
        # 两个depot的时间窗约束
        model.addConstr(b[0,k] >= TimeWindow[0][0])
        model.addConstr(b[0,k] <= TimeWindow[0][1])
        model.addConstr(b[nrows-1,k] >= TimeWindow[nrows-1][0])
        model.addConstr(b[nrows-1,k] <= TimeWindow[nrows-1][1])
        for j in range(len(Request)):
            # 运输请求i两个节点的左时间窗
            model.addConstr(b[Request[j][0],i]>=TimeWindow[Request[j][0]][0])
            model.addConstr(b[Request[j][1],i]>=TimeWindow[Request[j][1]][0])
            # 运输请求i两个节点的右时间窗
            model.addConstr(b[Request[j][0],i]<=TimeWindow[Request[j][0]][1])
            model.addConstr(b[Request[j][1],i]<=TimeWindow[Request[j][1]][1])
        
    
    ## ================== PDPTW===================
    
    # 约束（9）both origin and destination of a request must be served by the same vehicle
    # 保证取货后要有对应的送货，取货和送货由同一辆车完成
    for i in range(len(Request)):
        for j in range(len(Vehicles)):
            model.addConstr(x.sum(Request[i][0],'*',j)==x.sum('*',Request[i][1],j))
    
    # 约束 (10) delivery can only occur after pickup,先取后送货约束
    for i in range(len(Request)):
        for j in range(len(Vehicles)):
            model.addConstr(b[Request[i][0],j]<=b[Request[i][1],j])
    
    ## 设置目标函数
    # 最小化车辆总的行驶距离
    DistanceCost = 0
    for k in range(len(Vehicles)):
        for i in range(len(Locations)):
            for j in range(len(Locations)):
                if i != j:
                    DistanceCost += (DistanceMatrix[i,j] * x[i,j,k])
    model.setObjective(DistanceCost, GRB.MINIMIZE)
    model.update()
    
    model.__data = x,b,q
    
    return model,xindex
    
    
def print_solution():
    """  输出结果.

    具体描述：计算两点(x1, y1), (x2, y2)之间的Euclid距离.
    """
    return
    
    
    
try:
    
    start = time.time()
    
    # 数据生成方式1：读取数据
    # DataPath = 'lc101.txt' # 原始数据
    # DataPath = 'lc101(revised).txt' # 为了模型需要，虚拟增加了一个供车辆返回的depot，该depot只是序号不一样
    DataPath = 'smalltestinstance.txt' # 本数据笔者自己捏造的
    Vehicles,Locations,Demand,TimeWindow,ServiceTime,Request,nrows,EarliestTime,LatestTime = read_txt_data(DataPath)
    
    # 数据生成方式2：制造数据
    
    
    # 构建距离矩阵
    DistanceMatrix,LongestDistance = construct_distance_matrix(Locations)
    
    # 构建通行时间矩阵
    TimeMatrix = construct_time_matrix(Vehicles,DistanceMatrix)
    
    # 建立与优化模型
    model,xindex = build_pdptw_model(Vehicles,Locations,Demand,TimeWindow,ServiceTime,Request,nrows,EarliestTime,LatestTime,DistanceMatrix,LongestDistance,TimeMatrix)
    model.params.TimeLimit = 1000    # 设定模型求解时间
    model.write('PDPTW_%s.lp' % DataPath)
    model.write('PDPTW_%s.mps' % DataPath)
    model.setParam(GRB.Param.LogFile, 'PDPTW_%s.log' % DataPath)
    model.optimize()
    x,b,q = model.__data
    
    # 输出结果到控制台
    '''
    # 输出方式1
    xsol={}
    bsol={}
    qsol={}
    for i in xindex.keys():
        if x[i].x - 0.5 > 0:
            
            xsol[i] = 1
            
            bsol[i[0], i[2]]=b[i[0],i[2]].x
            bsol[i[1], i[2]]=b[i[1],i[2]].x
            
            qsol[i[0], i[2]]=q[i[0],i[2]].x
            qsol[i[1], i[2]]=q[i[1],i[2]].x
    print('xsol:')
    print(xsol)
    print('bsol:')
    print(bsol)
    print('qsol:')
    print(qsol)
    '''
    # 输出方式2
    for k in range(len(Vehicles)):
        for i in range(nrows):
            for j in range(nrows):
                if i != j:
                    if (x[i,j,k].x - 0.5 > 0):
                        print('tour for vehicle %s:' % k)
                        print('%s-->%s' % (i,j))
            
    print("Optimal solution:",model.ObjVal)
    
    # 计算程序运行时间
    end = time.time()
    print('程序运行时间：')
    print(end-start)

except GurobiError as exception:
    print('Error code ' + str(exception.errno) + ": " + str(exception))

except AttributeError:
    print('Encountered an attribute error')