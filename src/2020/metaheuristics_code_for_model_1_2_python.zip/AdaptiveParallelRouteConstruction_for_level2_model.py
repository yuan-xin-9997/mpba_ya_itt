# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 16:10:53 2020

@author: AtticusYuan
"""

"""
本代码实现 Adaptive Parallel Route Construction Heuristic（自适应并行路径构造算法）构造PDPTW问题的初始解
"""

import numpy as np
import time

class Node(object):
    '''
    顾客点类：
    c_id:Number,顾客点编号
    x:Number,点的横坐标
    y:Number,点的纵坐标
    demand:Number,点的需求量
    ready_time:Number,点的最早访问时间
    due_time:Number,点的最晚访问时间
    service_time:Number,点的服务时间
    belong_veh:所属车辆编号
    '''
    
    def __init__(self,c_id,x,y,demand,ready_time,due_time,service_time):
        self.c_id = c_id
        self.x = x
        self.y = y
        self.demand = demand
        self.ready_time = ready_time
        self.due_time = due_time
        self.service_time = service_time        
        self.belong_veh = None


class Vehicle(object):
    '''
    车辆类：
    v_id:Number,车辆编号
    cap:Number,车的最大载重量
    load:Number,车的载重量
    distance:Number,车的行驶距离
    violate_time:Number,车违反其经过的各点时间窗时长总和
    route:List,车经过的点index的列表
    start_time:List,车在每个点的开始服务时间
    ''' 
    
    def __init__(self,v_id:int,cap:int):
        self.v_id = v_id
        self.cap = cap
        self.load = 0
        self.distance = 0
        self.violate_time = 0
        self.route = [0]
        self.start_time = [0]
        
    # 插入节点
    def insert_node(self,node:int,index:int = 0) -> None:
        if index == 0:
            self.route.append(node) # 如果index=0，那么将node插入到车经过的点的后面
        else:
            self.route.insert(index,node) # 如果index不等于0，那么将node插入到route列表index索引处的位置
        # node.belong_veh = self.v_id
        self.update_info() # 类方法，参见下方，用来更新类对象veh的载量、距离、开始服务时间、时间窗违反
    
    #根据索引删除节点
    def del_node_by_index(self,index:int) -> None:
        self.route.pop(index)
        self.update_info()
        
    #根据对象删除节点
    def del_node_by_node(self,node:Node) -> None:
        self.route.remove(node.c_id)
        self.update_info()
        
    # 更新载重、距离、开始服务时间、时间窗违反
    def update_info(self) -> None:
        
        #更新载重
        cur_load = 0
        for n in self.route:
            cur_load += nodes[n].demand
        self.load = cur_load
        
        #更新距离
        cur_distance = 0
        for i in range(len(self.route)-1): 
            cur_distance += distance_matrix[self.route[i]][self.route[i+1]]
        self.distance = cur_distance
        
        #更新违反时间窗时长总和(硬时间窗,早到等待，不可晚到)
        arrival_time = 0
        self.start_time = [0]
        cur_violate_time = 0
        for i in range(1,len(self.route)): 
            arrival_time += distance_matrix[self.route[i-1]][self.route[i]] + nodes[self.route[i-1]].service_time
            if arrival_time > nodes[self.route[i]].due_time:
                cur_violate_time += arrival_time - nodes[self.route[i]].due_time
            elif arrival_time < nodes[self.route[i]].ready_time:
               arrival_time = nodes[self.route[i]].ready_time 
            self.start_time.append(arrival_time)
        self.violate_time = cur_violate_time

    def __str__(self): #重载print()
        routes = [n for n in self.route]
        description = '车{}详细信息:\n距离[{:.4f}]\n载重[{}]\n时间违反[{:.4f}]\n路径{}\n开始服务时间{}\n'.format(self.v_id,self.distance,self.load,self.violate_time,routes,self.start_time)
        return description


# 读取数据文件，返回车辆最大载重，最大车辆数，所有Node组成的列表   
def read_data(path:str) -> (int,int,list):  
    with open(path,'r',) as f:
        lines = f.readlines()
    capacity = (int)(lines[4].split()[-1])
    max_vehicle = (int)(lines[4].split()[0])
    lines = lines[9:] # 从depot点开始一直到最后一个客户点
    nodes = []
    for line in lines:
        info = [int(j) for j in line.split()]
        if len(info) == 7:
            node = Node(*info) # 创建Node类对象,一个*的作用是解压参数列表
            nodes.append(node) # 列表元素
    return capacity, max_vehicle, nodes 


# 计算距离矩阵
def cal_distance_matrix(nodes:list) -> np.array:
    distance_matrix = np.zeros((len(nodes),len(nodes)))
    for i in range(len(nodes)):
        for j in range(i+1,len(nodes)):
            if i != j: # 减少Redundant
                dis = np.sqrt((nodes[i].x - nodes[j].x)**2 +(nodes[i].y - nodes[j].y)**2)
                distance_matrix[i][j] = dis # 对称图，np的array
                distance_matrix[j][i] = dis
    return distance_matrix


# 自适应并行路径构造启发式算法，Adaptive Parallel Route Construction Heuristic (没有调整参数)
def aprch(capacity:int,w_dis = 0.6,w_urg = 0.11) -> (list,float):
    """输入：
        capacity：车辆容量
        w_d：距离的权重
        w_u：违背时间窗的权重
        w_w：等待时间的权重
       返回：插入的解对应车组成的list和总距离
    """
    
    w_wai = 1 - w_dis - w_urg
    FAILED = 1e6
    
    assigned_node_id = set() # 已被分配过的点的集合（没有加入depot 0
    
    num_veh_least = int(sum([ n.demand for n in nodes]) / capacity) + 1 # 最少需要的车辆数量，所有客户需求相加/车辆容量
    
    vehicles = [Vehicle(num_veh,capacity) for num_veh in range(num_veh_least)] # 创建num_veh_least个车辆Vehicle的类对象
    
    # 主循环
    while len(assigned_node_id) < len(nodes) - 1: # 当已经分配的顾客 小于 顾客综述
        
        fit_all = np.ones((len(vehicles),len(nodes) - 1)) * np.inf # 适应度矩阵：最少需要的车辆 * 客户数目
        
        # 计算每辆车末尾插入每个点的fitness（适应度）
        for k in vehicles:
            for n in range(1,len(nodes)):
                if n not in assigned_node_id: # 如果客户n没有被车辆服务过
                    fit_dis = distance_matrix[k.route[-1]][n] # 距离适应度：车辆k最后访问的点与n的距离
                    # 紧急适应度（时间窗违反）：点n最晚服务时间-(车辆k在最后访问点的开始服务时间+其服务时间+其到点n的距离)(也就是假设车速为1)
                    fit_urg = nodes[n].due_time - (k.start_time[-1] + nodes[k.route[-1]].service_time + fit_dis)
                    # 等待适应度：计算车辆如果访问n，那么需要等待的时间
                    fit_wai = max(0,nodes[n].ready_time - (k.start_time[-1] + nodes[k.route[-1]].service_time + fit_dis))
                    if fit_urg >= 0 and k.load + nodes[n].demand <= capacity: # 如果访问点n违反了时间窗，但是车辆的载量没有违反
                        # 因n从1开始，所以存储索引为 n-1（因为fit_all是车辆与客户适应度矩阵，比如n=1，那么对应于矩阵中的第1列，即索引为0）
                        fit_all[k.v_id][n-1] = w_dis * fit_dis + w_urg * fit_urg + w_wai * fit_wai
                    else:
                        fit_all[k.v_id][n-1] = FAILED # FAILED = 1e6，即只要违背了载量约束，那么去适应度就为Failed
                     
        # 判断是否需要新开一辆车（只用判断是否加入一辆车？？如果一辆不够怎么办？如果开的车辆超过最大可用车辆怎么办？）(这是在for循环里面)
        for row in range(len(vehicles)):
            # 因n从1开始，所以实际点编号为存储索引 + 1
            node_veh_failed = set(np.ravel(np.argwhere(fit_all[row] == FAILED)) + 1) # 对车辆row，展平其对应的Failed的node
            '''
            # 注：
            numpy.ravel() 展平的数组元素，顺序通常是"C风格"，返回的是数组视图（view，有点类似 C/C++引用reference的意味），修改会影响原始数组
            numpy.argwhere(a) Find the indices of array elements that are non-zero, grouped by element.
            '''
            if row == 0: # 如果车row没有Failed的点
                nodes_failed = node_veh_failed # 集合node_veh_failed为空集
            else:
                nodes_failed = nodes_failed & node_veh_failed # & 为集合set运算符，返回nodes_failed和node_veh_failed中都包含的元素
        if len(nodes_failed) > 0: # 如果Failed的node数量大于0，那么需要增加一辆车
            # 新加入一辆车，车ID是num_veh_least
            vehicles.append(Vehicle(num_veh_least,capacity))
            num_veh_least += 1
            fit_all = np.ones((len(vehicles),len(nodes) - 1)) * np.inf 
            # 重新计算每辆车末尾插入每个点的fitness
            for k in vehicles:
                for n in range(1,len(nodes)):
                    if n not in assigned_node_id:
                        fit_dis = distance_matrix[k.route[-1]][n]
                        fit_urg = nodes[n].due_time - (k.start_time[-1] + nodes[k.route[-1]].service_time + fit_dis)
                        fit_wai = max(0,nodes[n].ready_time - (k.start_time[-1] + nodes[k.route[-1]].service_time + fit_dis))
                        if fit_urg >= 0 and k.load + nodes[n].demand:
                            #因n从1开始，所以存储索引为 n-1
                            fit_all[k.v_id][n-1] = w_dis * fit_dis + w_urg * fit_urg + w_wai * fit_wai
                        else:
                            fit_all[k.v_id][n-1] = FAILED # FAILED = 1e6
                            
        # 选择最优的插入车和点
        veh_index, node_index = np.where(fit_all == np.min(fit_all))   
        veh_index = veh_index[0] # 如果有多个相同的最小值，那么选取第一个
        # 点编号 = 其存储索引 + 1
        node_index = node_index[0] + 1
        vehicles[veh_index].insert_node(node_index) # 将选中的最优点插入到最优车后面
        assigned_node_id.add(node_index)
    
    # 为每条路末尾加上 depot 0
    for k in vehicles:
        k.insert_node(0)     
    
    # 为每个顾客点更新所属车编号
    for v in vehicles:
        for i in range(1,len(v.route)-1):
            nodes[v.route[i]].belong_veh = v.v_id    
    
    return vehicles,sum([v.distance for v in vehicles])


# 主程序：APRCH构造初始解（自适应并行路径构造启发式算法，Adaptive Parallel Route Construction Heuristic）
if __name__ == '__main__':
    
    start = time.time()
    
    #读取数据
    path = '.\VRPTW_solomon\solomon_100\C101.txt'
    capacity, max_vehicle, nodes = read_data(path)         #获取车的载重，最大车数，顾客节点
    distance_matrix = cal_distance_matrix(nodes)           #将距离矩阵赋值给车辆的类变量
    
    # APRCH构造初始解
    vehicles_aprch,distance_aprch = aprch(capacity,0.69,0.11) 
    
    # 输出结果
    print('APRCH构造初始解的最优解（车辆总行驶距离）：{:.6f}'.format(distance_aprch))
    print()
    for veh in vehicles_aprch:
        print(veh)
    
    end = time.time()
    print('APRCH构造初始解耗时（单位：秒）{:.2f}'.format(end-start))