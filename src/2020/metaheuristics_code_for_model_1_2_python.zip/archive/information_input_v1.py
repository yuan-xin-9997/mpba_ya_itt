# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: information_input_v1.py
@time: 2020/7/25 20:30
"""

import random
import pandas as pd
from node import Node


## 制造的数据假设洋山只有三个独立的码头（洋一二、洋三、洋四），因为洋一和洋二合并了
def make_level1_data(vesseln, containern, truckn):
    """  制造数据.

    具体描述：根据一定原则制造第一阶段所需要的数据，需要尽可能的使用真实数据.

    字典数据结构描述
    -------
    泊位 berth = {} # 字典结构 泊位ID：泊位ID，该泊位所属的集装箱码头的ID，标识该泊位是干线泊位还是支线泊位
    箱区 block = {} # 字典结构 箱区ID：箱区ID，该箱区所属的集装箱码头ID,该箱区x坐标，该箱区y坐标
    码头 terminal = {} # 字典结构 码头ID：码头ID
    船舶 vessel = {} # 字典结构 船ID：船ID，预计到港时间，要求离港时间，标识该船舶是干线船还是支线船
    中转箱 container = {} # 字典结构 中转箱ID：中转箱ID，一程船ID，二程船ID

    数据生成原则
    -------
    ## 随机生成与随机分配

    # 缺点
    ## 可能由于数据的原因导致本阶段模型不可行
    ## 可能由于数据的原因导致第二阶段模型不可行

    """

    ### 算例一（中心模式，洋五为全支线码头）

    ## 前置信息（以算例为基准）
    terminaln = 4  # 以洋山港为例，洋山港共有4个码头，分别是洋一二、洋三、洋四、洋五
    berthn = [9, 7, 7, 15]  # 依次为洋一二、洋三、洋四、洋五的泊位数量，共38个泊位
    blockn = [18, 14, 14, 30]  # 依次为洋一二、洋三、洋四、洋五的箱区数量,共76个箱区，平均每一个泊位有2个箱区,

    # 每个码头箱区范围的长和宽（假设单个箱区长280m，宽50m，每个干线泊位后方有一个专属箱区，支线泊位后方也与一个箱区，但是箱区长100m，宽50m）
    block_length_width = {0: (2520, 100), 1: (1960, 100), 2: (1960, 100), 3: (1500, 100)}  # 0表示洋一二，1表示洋三，2表示洋四，3表示洋五

    # 四个码头道口之间的距离（区分进场道口与出场道口）
    terminalgatedistance = {}  # 使用Google Earth测量的洋山四个码头道口与道口之间的道路距离（单位：米）

    terminalgatedistance[0, 1] = 1630  # 洋一二-->洋三
    terminalgatedistance[1, 0] = 4822  # 洋三-->洋一二

    terminalgatedistance[0, 2] = 4763  # 洋一二-->洋四
    terminalgatedistance[2, 0] = 4730  # 洋四-->洋一二

    terminalgatedistance[0, 3] = 2590  # 洋一二-->洋五
    terminalgatedistance[3, 0] = 4109  # 洋五-->洋一二

    terminalgatedistance[1, 2] = 7306  # 洋三-->洋四
    terminalgatedistance[2, 1] = 7201  # 洋四-->洋三

    terminalgatedistance[1, 3] = 910  # 洋三-->洋五
    terminalgatedistance[3, 1] = 1619  # 洋五-->洋三

    terminalgatedistance[2, 3] = 7906  # 洋四-->洋五
    terminalgatedistance[3, 2] = 6522  # 洋五-->洋四

    for i in range(terminaln):
        terminalgatedistance[i, i] = 0

    Q = 1  # 集卡载量
    S = 500  # 集卡速度，30km/h=500m/min
    SchedulingDuration = 2880  # 规划周期长2天=2880分钟，[0-2880]

    # 码头
    terminal = {}  # 字典结构 码头ID：码头ID
    for i in range(terminaln):
        terminal[i] = i

    # 泊位（由于是中心模式，故洋一~洋四的泊位均为干线船泊位，洋五的泊位均为支线船泊位）
    berth = {}  # 字典结构 泊位ID：泊位ID，该泊位所属的集装箱码头的ID，干支线泊位标识（0标识干线泊位，1表示支线泊位）
    bthid = 0
    for tn in range(len(berthn)):  # 为每个码头tn分配泊位
        if tn != len(berthn) - 1:  # 洋一二、洋三、洋四，都是干线泊位
            for i in range(berthn[tn]):
                berth[bthid] = bthid, tn, 0
                bthid += 1
        elif tn == len(berthn) - 1:
            for i in range(berthn[tn]):
                berth[bthid] = bthid, tn, 1
                bthid += 1

    # 箱区（箱区坐标按每个码头实际情况单独讨论）
    gate_block = 1000  # 假设同一码头内部的箱区到道口的平均距离为1000
    block = {}  # 字典结构 箱区ID：箱区ID，该箱区所属的集装箱码头ID,该箱区x坐标，该箱区y坐标
    blkid = 0
    for tn in range(len(blockn)):  # blockn列表，依次表示每个码头拥有的箱区数量
        length = block_length_width[tn][0]  # 码头tn的箱区的长度
        width = block_length_width[tn][1]  # 码头tn的箱区的宽度
        xcoordinates = [0] * blockn[tn]
        ycoordinates = [0] * blockn[tn]

        x = 0
        y = 0
        for i in range(blockn[tn]):
            xcoordinates[i] = x
            ycoordinates[i] = y
            y += width / 2  # 论文假码头的箱区都是2排
            if (i + 3) % 2 == 0:  # 取余数
                x += length / berthn[tn]
                y = 0

        for i in range(blockn[tn]):
            block[blkid] = blkid, tn, xcoordinates[i], ycoordinates[i]
            blkid += 1

    # 船舶（如何解决模型二不可行的情况？或者模型二加惩罚成本？）
    # 按照论文，长江内支线中转：国际干线中转箱=7.5:2.5的比例来生成中转箱信息，即干线船：支线船=10:7.5
    vessel = {}  # 字典结构 船ID：船ID，预计到港时间，要求离港时间，干支线船标识（0表示干线船，1表示支线船）
    mainlinevesselid = []  # 列表，存储干线船的id
    feedvesselid = []  # 列表，存储支线船的id
    arrivaltime = [0] * vesseln  # 默认预计到港时间
    departuretime = [SchedulingDuration] * vesseln  # 默认要求离港时间
    for i in range(vesseln):
        vessel[i] = i, arrivaltime[i], departuretime[i], 0  # 船舶默认信息
        prob = random.uniform(0, 17.5)
        if prob < 10:  # 干线船，其时间窗更大,标识为0
            at = random.randint(0, 1320)  # 规划周期为2天=2880分钟，干线船的到港时间控制在第一天的0时-22时（随机生成一个整数）
            duration = random.randint(1200, 1560)  # 干线船的停靠时间控制在20h-26h，即1200-1560分钟之间（随机生成一个整数）
            dt = at + duration  # 要求离港时间=预计到港时间+停靠时间
            vessel[i] = i, at, dt, 0
            mainlinevesselid.append(i)
        elif prob > 10:  # 支线船，其时间窗更小，标识为1
            at = random.randint(0, 2280)  # 规划周期为2天=2880分钟，支线船的到港时间控制在两天的的0时- 24+14时（随机生成一个整数）
            duration = random.randint(120, 600)  # 干线船的停靠时间控制在2h-10h，即120-600分钟之间（随机生成一个整数）
            dt = at + duration  # 要求离港时间=预计到港时间+停靠时间
            vessel[i] = i, at, dt, 1
            feedvesselid.append(i)
        elif prob == 10:  # 如果prob=10，那么随机确定是干线还是支线
            indicator = random.choice([0, 1])
            if indicator == 0:
                at = random.randint(0, 1320)  # 规划周期为2天=2880分钟，干线船的到港时间控制在第一天的0时-22时（随机生成）
                duration = random.randint(1200, 1560)  # 干线船的停靠时间控制在20h-26h，即1200-1560分钟之间（随机生成
                dt = at + duration  # 要求离港时间=预计到港时间+停靠时间
                vessel[i] = i, at, dt, 0
                mainlinevesselid.append(i)
            elif indicator == 1:
                at = random.randint(0, 2280)  # 规划周期为2天=2880分钟，支线船的到港时间控制在两天的的0时- 24+14时（随机生成）
                duration = random.randint(120, 600)  # 干线船的停靠时间控制在2h-10h，即120-600分钟之间（随机生成）
                dt = at + duration  # 要求离港时间=预计到港时间+停靠时间
                vessel[i] = i, at, dt, 1
                feedvesselid.append(i)

    # 中转箱
    # 按照论文，长江内支线中转：国际干线中转箱=7.5:2.5的比例来生成中转箱信息
    container = {}  # 字典结构 中转箱ID：中转箱ID，一程船ID，二程船ID
    for i in range(containern):
        container[i] = i, random.randrange(vesseln), random.randrange(vesseln)  # 中转箱默认信息
        prob = random.uniform(0, 10)
        if prob < 7.5:  # 长江内支线中转箱，一程船和二程船为，其一为干线船，其二为支线船
            indicator = random.choice([0, 1])
            if indicator == 1:  # 一程船为干线船，二程船为支线船
                container[i] = i, random.choice(mainlinevesselid), random.choice(feedvesselid)
            else:  # 一程船为支线船，二程船为干线船
                container[i] = i, random.choice(feedvesselid), random.choice(mainlinevesselid)
        elif prob > 7.5:  # 国际中转，其一程船和二程船均为干线船
            container[i] = i, random.choice(feedvesselid), random.choice(feedvesselid)

    # 可用集卡数量（单位：辆）
    K = truckn

    ### 算例二（非中心模式）

    return terminal, berth, block, vessel, container, K, Q, S, SchedulingDuration, gate_block, terminalgatedistance


# 读取数据文件，返回最大车辆数K，车辆最大载重Q，车辆速度S，所有Node（task）组成的列表
def read_level2_data(DataPath):
    # 示例数据
    '''
    6	1	500
    0	0	0	2880	0	0	0	-1	-1
    1	1	1012	2880	10	0	2	1	0
    2	-1	0	810	10	1	0	46	0
    3	1	287	2880	10	0	4	47	1
    4	-1	0	1561	10	3	0	4	1
    5	1	269	2880	10	0	6	5	2
    6	-1	0	810	10	5	0	46	2
    7	1	368	2880	10	0	8	3	3
    8	-1	0	810	10	7	0	46	3
    9	1	287	2880	10	0	10	47	4
    10	-1	0	2640	10	9	0	44	4
    11	1	287	2880	10	0	12	47	5
    12	-1	0	1561	10	11	0	4	5
    13	1	368	2880	10	0	14	3	6
    14	-1	0	810	10	13	0	46	6
    15	1	269	2880	10	0	16	5	7
    16	-1	0	810	10	15	0	46	7
    17	1	287	2880	10	0	18	47	8
    18	-1	0	2466	10	17	0	0	8
    19	1	1012	2880	10	0	20	1	9
    20	-1	0	810	10	19	0	46	9
    21	0	0	2880	0	0	0	-2	-1
    '''
    with open(DataPath,'r') as f:
        lines = f.readlines()
    # max_vehicle = (int)(lines[0].split()[0])
    capacity = (int)(lines[0].split()[1])
    speed = (int)(lines[0].split()[2])
    lines = lines[1:] # 从depot点开始一直到最后一个客户点
    nodes = []
    for line in lines:
        info = [int(j) for j in line.split()]
        if len(info) == 9:
            node = Node(*info) # 创建Node类对象,一个*的作用是解压参数列表
            nodes.append(node) # 列表元素

    '''
    # 读取车辆信息
    VehiclesInfo = pd.read_table(DataPath, nrows=1, names=['K', 'C', 'S'])
    Vehicles = {}  # 车辆字典
    for i in range(VehiclesInfo.iloc[0, 0]):
        Vehicles[i] = [VehiclesInfo.iloc[0, 1], VehiclesInfo.iloc[0, 2]]  # 键i=车辆的序号，值为[车辆容量、车辆速度]
    '''

    # 读取Depot和任务信息
    ColumnNames = ['TaskNo', 'Demand', 'ET', 'LT', 'ST', 'PI', 'DI', 'BI', 'CI']
    TaskData = pd.read_table(DataPath, skiprows=[0], names=ColumnNames, index_col='TaskNo')
    TaskNumber = TaskData.shape[0]  # 取货点P+送货点D+depot(2个)的数量
    temp = pd.read_table(DataPath, skiprows=[0], names=ColumnNames)
    TaskList = temp['TaskNo'].values.tolist()  # 为了将TaskNo这一列提出成为列表

    # 提取Depot和取送货点的Demand
    Demand = {}
    for i in TaskList:
        if i not in Demand.keys():
            Demand[i] = TaskData.loc[i, 'Demand']

    # 提取Depot和取送货点的最早和最晚取送货时间及时间窗
    TimeWindow = {}
    for i in TaskList:
        if i not in TimeWindow.keys():
            TimeWindow[i] = [TaskData.loc[i, 'ET'], TaskData.loc[i, 'LT']]

    # 提取Depot和取送货点的服务时间ServiceTime
    ServiceTime = {}
    for i in TaskList:
        if i not in ServiceTime.keys():
            ServiceTime[i] = TaskData.loc[i, 'ST']

    # 提取运输Request
    # 对于取货任务，PICKUP索引为0，而同一行的DELIVERY索引给出相应送货任务的索引
    Request = {}
    count = 0  # 记录运输需求的数量
    for i in TaskList[1:-1]:
        if TaskData.loc[i, 'PI'] == 0:
            Request[count] = [i, TaskData.loc[i, 'DI']]  # 将取送货点组合在一起，键为count，值为[取货点，送货点]
            count += 1

    # 提取BlockID
    BlockID = {}
    for i in TaskList:
        if i not in BlockID.keys():
            BlockID[i] = TaskData.loc[i, 'BI']

    # 提取ContainerID
    ContainerID = {}
    for i in TaskList:
        if i not in ContainerID.keys():
            ContainerID[i] = TaskData.loc[i, 'CI']
    
    # 为了防止意外情况发生，假设最大可用的数量=中转箱的数量,也就是最差的情况，一辆车完成一个中转箱的任务
    max_vehicle = len(Request)
    
    return max_vehicle,capacity,speed,nodes,Demand,TimeWindow,ServiceTime,Request,BlockID,ContainerID,TaskNumber,TaskList