# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: main.py
@time: 2020/7/25 20:23
@description:用 Gurobi+Solomon插入算法构造初始解+禁忌搜索算法 求解 多码头泊位分配+箱区选位+ITTRP（PDPTW）
"""


import time

from gurobipy import GRB
from gurobipy import *

from information_input_v2 import make_level1_data
from information_input_v2 import read_level2_data

from distance_time_matrix import construct_distance_matrix
from distance_time_matrix import construct_time_matrix
from check_feasible import check_model_feasible
from assistants import compute_parameter_aided_Parameter
from assistants import build_pd_pair
from assistants import cal_pd_distance_time
from assistants import clear_dir
from convert import level1_to_level2

from model_level1_by_gurobi import bulid_cp_model
from solomon_insertion_for_model_level2 import solomon_i1
from tabu_search_for_model_level2 import tabu_search

from write_solution import write_level1_solution
#from write_solution import write_final_solution


if __name__ == '__main__':

    start = time.time()

    ### 阶段一读取数据与辅助工作（阶段二的数据已经隐含在这里面了）

    ## 数据读取
    terminal,berth,block,vessel,container,K,Q,S,SchedulingDuration,gate_block,terminalgatedistance = make_level1_data(5,10)  # 船舶数量，中转箱数量，可用集卡数量
    clear_dir() # 清空文件夹
    
    level1_start_time = time.time()
    
    ## 计算阶段一的辅助参数
    fcsberth,barberth,c1v,c2v,mb = compute_parameter_aided_Parameter(terminal,berth,block,vessel,container)

    ## 第一阶段模型建立（Gurobi）
    model_level1 = bulid_cp_model(terminal, berth,block,vessel,container,fcsberth,barberth,c1v,c2v,mb)

    ## 第一阶段Gurobi模型Solution Pool参数设置
    # 限制模型收集多少可行解的数量
    # level1_solution_number = len(vessel) * len(container) * len(berth) * len(block)  # 数字过大
    level1_solution_number = len(container) * len(block)
    model_level1.setParam(GRB.Param.PoolSolutions, level1_solution_number)
    # 设置解池搜索模式为2，即 the MIP to do a systematic search for the n best solutions（n为设定的要收集的可行解的数量）
    model_level1.setParam(GRB.Param.PoolSearchMode, 2)
    # 设置收集的可行解的值与最优值的gap值，Limit the search space by setting a gap for the worst possible solution that will be accepted
    model_level1.setParam(GRB.Param.PoolGap, 10)

    ## 第一阶段模型求解
    model_level1.optimize()

    ## 检验第一阶段模型是否可行，如果不可行，则计算IIS，并写入到ilp文件，并打印IIS约束的名称
    check_model_feasible(model_level1)

    ## 输出第一阶段收集的可行解的数量，Print number of solutions stored
    nSolutions = model_level1.SolCount
    yvb,U,V = model_level1.__data
    '''
    print('所有找到的可行解的目标函数值依次为:')
    for e in range(nSolutions):
        model_level1.setParam(GRB.Param.SolutionNumber, e)
        print('%g ' % model_level1.PoolObjVal)
    print('找到第一阶段模型可行的泊位分配和箱区选位的方案数量为: ', nSolutions)
    '''
    ## 将第一阶段模型的所有可行分配方案写入到文件当中
    write_level1_solution(vessel, container, berth, mb, model_level1, nSolutions, yvb, U, V)
    print('正在将第一阶段模型的分配方案写入到文件夹中，请稍等……')
    level1_end_time = time.time()

    ## 阶段一与阶段二转化（将第一阶段的每一个可行分配方案，转化为第二阶段可读的初始信息）
    level1_to_level2(terminal,berth,block,vessel,container,K,Q,S,SchedulingDuration,nSolutions, model_level1,mb)
    print('正在将第一阶段模型的分配方案转化为第二阶段初始信息，并写入到文件夹中，请稍等……')
    level2_start_time = time.time()
    
    ## 阶段一的每一个可行解输出为供阶段二可读的数据文件，并调用阶段二的模型进行求解
    Best_Total_Cost = 1e10  # 阶段二的目标函数，α*时间窗违背成本+β*车辆启用成本+γ*车辆行驶成本，其中α≫β≫γ，依次为1000,100,1
    Best_level1_solution = -1  # 最好的第一阶段分配方案
    f = open("两阶段模型求解的最终结果.txt", 'w')
    for i in range(nSolutions):
        
#        if i != 0:  # 先暂时求一个解
#            break
        print("")
        print("====================第一阶段解 %s 对应的第二阶段模型求解中====================" % i)

        ## 数据读取

        # 数据路径
        DataPath = "./level2_initial_info/leve1_solution_%s.txt" % i

        # 读取第二阶段数据（建立Node类对象）
        max_vehicle,capacity,speed,nodes,Demand,TimeWindow,ServiceTime,Request,BlockID,ContainerID,TaskNumber,TaskList = read_level2_data(DataPath)
        capacity_list = [capacity] * max_vehicle

        ## 辅助计算

        # 构建Task与Task之间的距离矩阵
        DistanceMatrix,TaskList_BlockID = construct_distance_matrix(block, gate_block, terminalgatedistance, TaskList, BlockID)

        # 构建Task与Task之间的通行时间矩阵
        TimeMatrix = construct_time_matrix(DistanceMatrix, speed)

        # 建立PD-pair类对象
        pd_nodes = build_pd_pair(Request, DistanceMatrix, TimeMatrix, TaskList_BlockID, TimeWindow, ServiceTime, ContainerID, TaskList)

        # 构建PD点对之间的通行距离矩阵和通行时间矩阵
        PD_Travel_Distance, PD_Travel_Time = cal_pd_distance_time(pd_nodes, DistanceMatrix, TimeMatrix)

        ## Solomon插入算法构造初始路径
        vehicles_sol,obj_sol = solomon_i1(TaskList, nodes, max_vehicle, pd_nodes, capacity_list, speed, DistanceMatrix)
        
        ## 将Solomon初始解输入到TabuSearch算法当中继续求解
        global_best_vehs, global_best_obj = tabu_search(vehicles_sol, pd_nodes)

        # 打印结果
        print("")
        total_travel_distance = 0
        total_violate_soft_time = 0
        for veh in global_best_vehs:
            print('--------------------------------------------------------------')
            print(veh)
            total_travel_distance += veh.distance
            total_violate_soft_time += veh.total_soft_violate_time
        print('--------------------------------------------------------------')
        print("%s辆车一共违背的软时间窗：%s 分钟" % (len(global_best_vehs),total_violate_soft_time))
        print("总共使用的车辆数量：%s 辆" % len(global_best_vehs))
        print("%s辆车一共行驶的距离：%s 米" % (len(global_best_vehs),total_travel_distance))
        
        # α、β、γ的系数依次为1000,100,1，每违背一分钟时间窗惩罚10元，每辆车的启用成本为500元，车辆行驶成本每公里1元
        # Total_Cost = cal_model_obj(vehicles)
        print("阶段二模型的目标函数为：%s" % global_best_obj)
        print("禁忌搜索提升目标函数值：",obj_sol - global_best_obj)
        
        # 判断（要将三种成本换成人民币来算）
        if global_best_obj < Best_Total_Cost:
            Best_Total_Cost = global_best_obj
            Best_level1_solution = i
            
    
    level2_end_time = time.time()
    
    ### 两阶段最终结果
    print("")
    print("========================================================")
    print('找到第一阶段模型可行的泊位分配和箱区选位的方案数量为: ', nSolutions)
    print("最好的第一阶段分配方案为 level1_solution_%s" % Best_level1_solution)
    print("对应的第二阶段的成本为：%s" % Best_Total_Cost)
    f.write(str("最好的第一阶段分配方案为 level1_solution_%s" % Best_level1_solution))
    f.write(str("对应的第二阶段的成本为：%s" % Best_Total_Cost))
    
    f.close()
    

    ### 计算程序运行时间
    print()
    print('第一阶段模型程序运行时间：',level1_end_time - level1_start_time,'秒')
    print('第二阶段模型程序运行时间：',level2_end_time - level2_start_time,'秒')
    end = time.time()
    print('Gurobi+启发式算法求解两阶段模型的程序运行时间：', end - start, '秒')