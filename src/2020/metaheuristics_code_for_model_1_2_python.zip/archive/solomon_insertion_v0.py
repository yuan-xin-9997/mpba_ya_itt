# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: solomon_insertion_for_model_level2.py
@time: 2020/7/25 20:33
"""

"""
=本代码实现改造Solomon插入算法用来构造ITTRP（PDPTW）问题的初始解；

=注意
==本代码从Solomon插入算法构造VRPTW问题初始解的代码上改进而来，要改进的地方如下：
===读取数据read_data部分，按照读取小论文第二阶段初始数据的格式来读取（已完成）
===约束：先取货后送货的处理（已完成）
===约束：同一任务的取货点和送货点均由同一辆车完成（已完成）
===约束，车辆载量约束的处理（每时的载量必须大于0，且小于车辆的最大载量）
===时间窗约束：可以违背时间窗（但是输入的数据要保证，车辆服务一个PD点对要求是可行解）
"""

import numpy as np
import copy
from vehicle import Vehicle


# solomon_i1:种子顾客选取策略为最远顾客。构造初始可行的路径。
def solomon_i1(TaskList, nodes, max_vehicle, pd_nodes, capacity_list, speed, DistanceMatrix, alpha1=1, lam= 1, mu= 1):
    """
    传入：
        Tasklist = [-1,p_id,d_id,...,p_id,d_id,-2]
        max_vehicle int:最大可使用的车辆数量
        pd_nodes = [由PDNode类对象组成的列表]，按TaskList中的pd顺序依次组成
        capacity_list 车辆容量列表
        alpha1=1
        lam=1
        mu=1
    返回：
       插入的解对应车组成的list
    """

    vehicles = []
    assigned_node_id = [TaskList[0]]  # 已被分配过的点的列表,开始depot和结束depot为默认已分配的点（见下方）

    for num_veh in range(max_vehicle):  # 为每辆车分配PD点

        # 如果所有节点都被安排了，则跳出循环，可以直接输出构造的初始路径
        if len(assigned_node_id) == len(TaskList):
            break

        # 否则，新安排一辆车服务一条路径,创建车辆Vehicle类对象，车辆ID为 num_veh，车辆最大载量为capacity_list[num_veh]，车速为spped
        veh = Vehicle(num_veh, capacity_list[num_veh], speed, DistanceMatrix, nodes)
        veh.cal_time_matrix()

        # 寻找第一个插入的PD点对：未分配的PD点对中，P点距离depot的距离+pd之间的距离 最远的点
        '''
        max_dis = 0
        for init_pd_node in pd_nodes: # 寻找车辆第一个访问的P取货点
            if init_pd_node.p_id in assigned_node_id and init_pd_node.d_id in assigned_node_id:
                continue
            elif max_dis < DistanceMatrix[TaskList[0], init_pd_node.p_id] + init_pd_node.travel_distance:
                max_dis = DistanceMatrix[TaskList[0], init_pd_node.p_id] + init_pd_node.travel_distance
                # init_node_p_id = pd_node.p_id
                # init_node_d_id = pd_node.d_id
        '''
        
        # 寻找第一个插入路径总的PD点对：未分配的PD点对中，PD任务时间窗+P点左时间窗最小的PD点对
        min_time = np.inf
        for init_pd_node in pd_nodes: # 寻找车辆第一个访问的P取货点
            if init_pd_node.p_id in assigned_node_id and init_pd_node.d_id in assigned_node_id:
                continue
            elif init_pd_node.time_window_period + init_pd_node.p_time_window[0] < min_time:
                min_time = init_pd_node.time_window_period + init_pd_node.p_time_window[0]
        veh.insert_pd_node(init_pd_node.p_id, init_pd_node.d_id)  # 将PD点对P的ID和D的ID插入到车辆路径当中
        assigned_node_id.append(init_pd_node.p_id)  # 将PD点对P的ID和D的ID加入已分配过的点的集合
        assigned_node_id.append(init_pd_node.d_id)
        veh.insert_end_depot(TaskList[-1])  # 将结束depot加入路径末尾
        
        # 在当前车辆veh中每条路插入PD点对，每次最多插入所有的PD点对
        for num_inserted in range(len(pd_nodes)):

            min_set_c1 = np.zeros((2, len(pd_nodes)))  # 存储c1，第一行依次为pd_node的最佳插入位置，第二行为其对应的c1值
            is_feasible = False  # 判断是否还有可以插入的点（由于互拖问题的特殊性，可以不用考虑载重量约束，如果违背了硬时间窗那么不可行）

            # 计算每个PD点对pd_node的最优c1，即每个顾客点u的最优插入的位置
            for pd_node in pd_nodes:

                if pd_node.p_id in assigned_node_id and pd_node.d_id in assigned_node_id:
                    # 如果PD点对已经分配了车辆
                    min_set_c1[0][pd_node.pd_id] = pd_node.pd_id  # 第一行存储pd_node的最佳插入位置
                    min_set_c1[1][pd_node.pd_id] = np.inf  # 第二行存储pd_node的对应的c1值，已被分配过的pd点对的c1设置为np.inf
                    # is_feasible = False
                    continue

                else:  # 如果PD点对未分配路径，寻找最佳插入位置

                    # 存储c1，是一个numpy的ndarray，其值为将pd_node插入到对应索引位置的c1值
                    c1 = np.array([0] * len(veh.pd_route), dtype='float')

                    # 计算c1_1和c1_2
                    for i in range(1, len(veh.pd_route)): # 遍历pd_route=[-1,[p1,d1],[p2,d2],...,[pn,dn],-2]中从第一个pd点对后的所有点

                        # 双重潜拷贝(copy)实现深拷贝(deepcopy),提升性能
                        temp_veh = copy.copy(veh)
                        temp_veh.route = copy.copy(veh.route)
                        temp_veh.pd_route = copy.copy(veh.pd_route)

                        temp_veh.insert_pd_node(pd_node.p_id, pd_node.d_id, i)  # 将pd_node插入到索引i的位置

                        if temp_veh.total_hard_violate_time != 0:  # 如果违背了硬时间窗，则该插入操作不可行

                            # min_set_c1[0][pd_node] = pd_node  # 第一行存储pd_node的最佳插入位置
                            # min_set_c1[1][pd_node] = np.inf  # 第二行存储pd_node的对应的c1值，违背硬时间窗的pd点对的c1设置为np.inf
                            c1[i] = np.inf
                            # is_feasible = False

                        else:

                            # c1_1 将pd_node插入到索引i的位置，车辆增加行驶的距离

                            if temp_veh.pd_route[i-1] == TaskList[0]:  # 如果是插在开始depot之后

                                c1_1 = temp_veh.distance_matrix[TaskList[0],pd_node.p_id] + \
                                       temp_veh.distance_matrix[pd_node.d_id, temp_veh.pd_route[i][0]] + \
                                       pd_node.travel_distance - \
                                       mu * temp_veh.distance_matrix[TaskList[0],temp_veh.pd_route[i][0]]

                                c1_2 = temp_veh.start_time[temp_veh.pd_route[i+1][0]] + temp_veh.start_time[temp_veh.pd_route[i+1][1]] - \
                                       veh.start_time[temp_veh.pd_route[i][0]] - veh.start_time[temp_veh.pd_route[i][1]]

                                # c1 = alpha1 * c1_1 + (1 - alpha1) * c1_2
                                c1[i] = alpha1 * c1_1 + (1 - alpha1) * c1_2
                                '''
                                c1_1 = DistanceMatrix[veh.route[i]][u] + \
                                       DistanceMatrix[u][veh.route[i + 1]] - \
                                       mu * DistanceMatrix[veh.route[i]][veh.route[i + 1]]
                                c1_2 = temp_veh.start_time[i + 2] - veh.start_time[i + 1]
                                c1[i] = alpha1 * c1_1 + (1 - alpha1) * c1_2
                                '''
                                is_feasible = True  # 可以插入

                                # min_set_c1[0][pd_node] = pd_node
                                # min_set_c1[1][pd_node] = c1

                            elif temp_veh.pd_route[i] == TaskList[-1]:  # 如果插在结束depot之前

                                c1_1 = temp_veh.distance_matrix[temp_veh.pd_route[i-1][1], pd_node.p_id] + \
                                       temp_veh.distance_matrix[pd_node.d_id, TaskList[-1]] + \
                                       pd_node.travel_distance - \
                                       mu * temp_veh.distance_matrix[temp_veh.pd_route[i-1][1], TaskList[-1]]

                                c1_2 = temp_veh.start_time[TaskList[-1]] - veh.start_time[TaskList[-1]]

                                # c1 = alpha1 * c1_1 + (1 - alpha1) * c1_2
                                c1[i] = alpha1 * c1_1 + (1 - alpha1) * c1_2

                                is_feasible = True

                                # min_set_c1[0][pd_node] = pd_node
                                # min_set_c1[1][pd_node] = c1

                            elif temp_veh.pd_route[i-1] != TaskList[0] and temp_veh.pd_route[i-1] != TaskList[-1]:  # 插在两个pd点对之间

                                c1_1 = temp_veh.distance_matrix[temp_veh.pd_route[i - 1][1], pd_node.p_id] + \
                                       temp_veh.distance_matrix[pd_node.d_id, temp_veh.pd_route[i][0]] + \
                                       pd_node.travel_distance - \
                                       mu * temp_veh.distance_matrix[temp_veh.pd_route[i - 1][1], temp_veh.pd_route[i][0]]

                                c1_2 = temp_veh.start_time[temp_veh.pd_route[i+1][0]] + temp_veh.start_time[temp_veh.pd_route[i+1][1]] - \
                                       veh.start_time[temp_veh.pd_route[i][0]] - veh.start_time[temp_veh.pd_route[i][1]]

                                c1 = alpha1 * c1_1 + (1 - alpha1) * c1_2

                                is_feasible = True

                                # min_set_c1[0][pd_node] = pd_node
                                # min_set_c1[1][pd_node] = c1

                    # 获得一个点插入的所有位置中c1增量的最小值和插入的位置
                    min_c1 = np.min(c1)  # 最小c1
                    min_c1_index = np.argmin(c1)
                    min_set_c1[0][pd_node.pd_id] = min_c1_index  # 第一行存储第u个点的最佳插入位置
                    min_set_c1[1][pd_node.pd_id] = min_c1  # 第二行存储第u个点的最小c1增量

            if not is_feasible:  # 该条路径没有可以插入的点，则结束该条路径
                vehicles.append(veh)
                break

            # 计算每个PD点对的c2
            # c2 = [lam * DistanceMatrix[0][u] - min_set_c1[1][u - 1] for u in range(1, len(nodes))]
            c2 = [lam * (veh.distance_matrix[-1,pd_nodes[pd].p_id] + pd_nodes[pd].travel_distance) - min_set_c1[1][pd] for pd in range(len(pd_nodes))]

            # 找出最大c2对应的顾客点和和对应顾客点的最优插入位置
            insert_pd_node_id = c2.index(max(c2))
            insert_position = min_set_c1[0][c2.index(max(c2))]

            # 插入上述点
            veh.insert_pd_node(pd_nodes[insert_pd_node_id].p_id, pd_nodes[insert_pd_node_id].d_id, int(insert_position))

            # 判断载重约束
            # if veh.load > veh.cap:
            #     veh.del_node_by_node(nodes[insert_node_id])
            #     vehicles.append(veh)
            #     break
            # else:
            #     assigned_node_id.add(insert_node_id)

    # 为每个顾客点添加所属车编号
    for v in vehicles:
        for i in range(1, len(v.pd_route) - 1):
            pd_nodes[v.route[i]].belong_veh = v.v_id

    return vehicles