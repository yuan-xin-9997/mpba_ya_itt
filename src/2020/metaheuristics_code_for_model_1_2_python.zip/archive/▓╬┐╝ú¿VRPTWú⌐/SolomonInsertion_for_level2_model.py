# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 16:10:33 2020

@author: AtticusYuan
"""

"""
=本代码实现改造Solomon插入算法构造PDPTW问题的初始解；

=注意
==本代码从Solomon插入算法求VRPTW问题的代码上改进而来，要改进的地方如下：
===读取数据read_data部分，按照读取pdptw benchmark格式数据读取（已完成）
===约束：先取货后送货的处理
===约束：同一任务的取货点和送货点均由同一辆车完成
===约束，车辆载量约束的处理（每时的载量必须大于0，且小于车辆的最大载量
===时间窗约束：可以违背时间窗
"""

import numpy as np
import copy
import time


class Node(object):
    '''
    顾客点类：
    c_id:Number,顾客点编号（任务点编号）
    x:Number,点的横坐标
    y:Number,点的纵坐标
    demand:Number,点的需求量
    ready_time:Number,点的最早访问时间
    due_time:Number,点的最晚访问时间
    service_time:Number,点的服务时间
    pickup_index:Number,点如果是取货任务，那么此值等于0；点如果是送货任务，那么此值对应其取货任务的点编号
    delivery_index:Number,点如果是送货任务，那么此值等于0；点如果是取货任务，那么此值对应其送货任务的点编号
    belong_veh:所属车辆编号
    '''
    
    def __init__(self,c_id,x,y,demand,ready_time,due_time,service_time,pickup_index,delivery_index):
        self.c_id = c_id
        self.x = x
        self.y = y
        self.demand = demand
        self.ready_time = ready_time
        self.due_time = due_time
        self.service_time = service_time        
        self.pickup_index = pickup_index
        self.delivery_index = delivery_index
        self.belong_veh = None


class Vehicle(object):
    '''
    车辆类：
    v_id:Number,车辆编号
    cap:Number,车的最大载重量
    load:Number,车的载重量
    distance:Number,车的行驶距离
    violate_time:Number,车违反其经过的各点时间窗时长总和
    route:List,车经过的点index的列表
    start_time:List,车在每个点的开始服务时间
    ''' 
    
    def __init__(self,v_id:int,cap:int):
        self.v_id = v_id
        self.cap = cap
        self.load = 0
        self.distance = 0
        self.violate_time = 0
        self.route = [0]
        self.start_time = [0]
        
    # 插入节点
    def insert_node(self,node:int,index:int = 0) -> None:
        if index == 0:
            self.route.append(node) # 如果index=0，那么将node插入到车经过的点的后面
        else:
            self.route.insert(index,node) # 如果index不等于0，那么将node插入到route列表index索引处的位置
        # node.belong_veh = self.v_id
        self.update_info() # 类方法，参见下方，用来更新类对象veh的载量、距离、开始服务时间、时间窗违反
    
    #根据索引删除节点
    def del_node_by_index(self,index:int) -> None:
        self.route.pop(index)
        self.update_info()
        
    #根据对象删除节点
    def del_node_by_node(self,node:Node) -> None:
        self.route.remove(node.c_id)
        self.update_info()
        
    # 更新载重、距离、开始服务时间、时间窗违反
    def update_info(self) -> None:
        
        #更新载重
        cur_load = 0
        for n in self.route:
            cur_load += nodes[n].demand
        self.load = cur_load
        
        #更新距离
        cur_distance = 0
        for i in range(len(self.route)-1): 
            cur_distance += distance_matrix[self.route[i]][self.route[i+1]]
        self.distance = cur_distance
        
        #更新违反时间窗时长总和(硬时间窗,早到等待，不可晚到)
        arrival_time = 0
        self.start_time = [0]
        cur_violate_time = 0
        for i in range(1,len(self.route)): 
            arrival_time += distance_matrix[self.route[i-1]][self.route[i]] + nodes[self.route[i-1]].service_time
            if arrival_time > nodes[self.route[i]].due_time:
                cur_violate_time += arrival_time - nodes[self.route[i]].due_time
            elif arrival_time < nodes[self.route[i]].ready_time:
               arrival_time = nodes[self.route[i]].ready_time 
            self.start_time.append(arrival_time)
        self.violate_time = cur_violate_time

    def __str__(self): # 重载print()
        # __str__方法,返回对象的描述信息，print函数输出时使用
        routes = [n for n in self.route]
        description = '车{}详细信息:\n距离[{:.4f}]\n载重[{}]\n时间违反[{:.4f}]\n路径{}\n开始服务时间{}\n'.format(self.v_id,self.distance,self.load,self.violate_time,routes,self.start_time)
        return description


# 读取数据文件，返回车辆最大载重，最大车辆数，所有Node组成的列表   
def read_data(path:str) -> (int,int,list):  
    with open(path,'r') as f:
        lines = f.readlines()
    capacity = (int)(lines[0].split()[1])
    max_vehicle = (int)(lines[0].split()[0])
    lines = lines[1:] # 从depot点开始一直到最后一个客户点
    nodes = []
    for line in lines:
        info = [int(j) for j in line.split()]
        if len(info) == 9:
            node = Node(*info) # 创建Node类对象,一个*的作用是解压参数列表
            nodes.append(node) # 列表元素
    return capacity, max_vehicle, nodes 


# 计算距离矩阵
def cal_distance_matrix(nodes:list) -> np.array:
    distance_matrix = np.zeros((len(nodes),len(nodes)))
    for i in range(len(nodes)):
        for j in range(i+1,len(nodes)):
            if i != j: # 减少Redundant
                dis = np.sqrt((nodes[i].x - nodes[j].x)**2 +(nodes[i].y - nodes[j].y)**2)
                distance_matrix[i][j] = dis # 对称图，np的array
                distance_matrix[j][i] = dis
    return distance_matrix


#solomon_i1:种子顾客选取策略为最远顾客   
def solomon_i1(max_vehicle:int,capacity_list:list,alpha1:float = 1,lam:float = 1,mu:float = 1) -> (list,float):
    """传入：max_vehicle,capacity_list,nodes,alpha1=1,lam=1,mu=1
       返回：插入的解对应车组成的list和总距离
    """
    
    vehicles = []
    assigned_node_id = set([0]) #已被分配过的点的集合,depot 0为默认已分配的点
    
    for num_veh in range(max_vehicle): # 外层循环，为每辆车分配客户
        
        # 如果所有节点都被安排了，则跳出循环
        if len(assigned_node_id) == len(nodes):
            break
        
        # 新安排一辆车服务一条路径
        veh = Vehicle(num_veh,capacity_list[num_veh]) # 创建车辆Vehicle类对象，车辆ID为 num_veh，车辆最大载量为capacity_list[num_veh]
        
        # 寻找第一个插入点：未分配的点中距离depot0最远的点
        max_dis = 0
        for i in range(1,len(nodes)):
            if i in assigned_node_id:
                continue
            elif max_dis < distance_matrix[0][i]:
                max_dis = distance_matrix[0][i]
                init_node_id = i # 寻找车辆第一个访问的客户
        veh.insert_node(init_node_id)           # 路径的第二个点为第一个插入点，将init_node_id插入到类对象veh中
        assigned_node_id.add(init_node_id)      # 加入已分配过的点的集合
        veh.insert_node(0)                      # 将depot0加入路径末尾
        
        # 为每条路插入顾客，每次至多插入len(nodes)-1个顾客(也就是除了depot0以外的客户都可以插入)
        for num_inserted in range(len(nodes)-1):  
            
            min_set_c1 = np.zeros((2,len(nodes)-1)) # 解释见下方
            is_feasible = False  # 判断是否还有可以插入的点（不违反时间窗约束，载重量约束见下方）
            
            # 计算每个顾客点u的最优c1，即每个顾客点u的最优插入的位置
            for u in range(1,len(nodes)):
                
                if u in assigned_node_id: # 如果node u已经分配了路径
                    min_set_c1[0][u-1] = u-1 #第一行存储第u个点的最佳插入位置
                    min_set_c1[1][u-1] = np.inf #第二行存储第u个点的最小c1增量，已被分配过的点的min_c1设置为inf
                    continue
                
                else:   #  如果node u未分配路径
                    
                    c1 = np.array([0]*(len(veh.route)-1),dtype = 'float') # 存储c1
                    
                    for i in range(len(veh.route)-1): # 计算c1_1和c1_2
                        # 双重潜拷贝(copy)实现深拷贝(deepcopy),提升性能
                        temp_veh = copy.copy(veh)
                        temp_veh.route = copy.copy(veh.route)
                        temp_veh.insert_node(u,i+1) # 将u插入到索引i+1的位置
                        
                        if temp_veh.violate_time != 0: # 载重量约束见下方
                            
                            c1[i] = np.inf
                            
                        else:
                            
                            c1_1 = distance_matrix[veh.route[i]][u] + \
                            distance_matrix[u][veh.route[i+1]] - \
                            mu*distance_matrix[veh.route[i]][veh.route[i+1]]
                            
                            c1_2 = temp_veh.start_time[i+2] - veh.start_time[i+1]
                            
                            c1[i] = alpha1*c1_1+ (1-alpha1)*c1_2
                            
                            is_feasible = True
                            
                    #获得一个点插入的所有位置中c1增量的最小值和插入的位置
                    min_c1 = np.min(c1) # 最小c1
                    min_c1_index = np.argmin(c1)
                    min_set_c1[0][u-1] = min_c1_index #第一行存储第u个点的最佳插入位置
                    min_set_c1[1][u-1] = min_c1       #第二行存储第u个点的最小c1增量
                    
            if is_feasible == False: # 该条路径没有可以插入的点，则结束该条路径
                vehicles.append(veh)
                break
            
            # 计算每个顾客点的c2
            c2 = [lam*distance_matrix[0][u] - min_set_c1[1][u-1] for u in range(1,len(nodes))]
            
            # 找出最大c2对应的顾客点和和对应顾客点的最优插入位置
            insert_node_id = c2.index(max(c2)) + 1
            insert_position = min_set_c1[0][c2.index(max(c2))] + 1
            
            # 插入上述点
            veh.insert_node(insert_node_id,int(insert_position))
            
            # 判断载重约束
            if veh.load > veh.cap:
                veh.del_node_by_node(nodes[insert_node_id])
                vehicles.append(veh)
                break
            else:
                assigned_node_id.add(insert_node_id)
                
    # 为每个顾客点添加所属车编号
    for v in vehicles:
        for i in range(1,len(v.route)-1):
            nodes[v.route[i]].belong_veh = v.v_id
    
    return vehicles,sum([v.distance for v in vehicles])


# 主程序:Solomon插入算法构造初始解
if __name__ == '__main__':

    start = time.time()
    
    #读取数据
    path = '.\li&lim benchmark instance(revised)\pdp100_revised\lc101.txt'
    capacity, max_vehicle, nodes = read_data(path)         #获取车的载重，最大车数，顾客节点
    distance_matrix = cal_distance_matrix(nodes)           #将距离矩阵赋值给车辆的类变量
    capacity_list =[capacity]*max_vehicle # 创建每辆车最大载量列表
    
    # Solomon插入算法求解
    vehicles_sol,distance_sol = solomon_i1(max_vehicle,capacity_list)   
    
    # 打印结果
    print('Solomon插入算法构造的初始解最优解（车辆总行驶距离）：{:.6f}'.format(distance_sol))
    for veh in vehicles_sol:
        print(veh)
        
    
    end = time.time()
    print('Solomon插入算法构造初始解耗时（单位：秒）：{:.2f}'.format(end-start))