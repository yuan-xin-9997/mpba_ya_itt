# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: random's seed.py
@time: 2020/7/30 19:48
@description:
"""

"""
random.seed() 应用
功能：生成相同的随机数。
"""
import random

#人工指定随机种子
def dataBySeed(seed,num,M):
    random.seed(seed)
    randdata=[]
    for i in range(num):
        randdata.append(random.randint(0,M)) #生成0~M之间随机数，包含0和M
    return randdata

#以系统时间做为种子
def dataBySys(num,M):
    randdata=[]
    for i in range(num):
        randdata.append(random.randint(0,M)) #生成0~M之间随机数，包含0和M
    return randdata

if __name__=='__main__':
    seed=9 #随机种子,限定以该种子生成随机数序列。种子相同，则生成的随机数序列相同
    num=9 #每次生成多少个随机数
    M=4 #随机数取值范围
    N=10 #生成10批序列
    seedData=[] #指定种子，生成序列
    sysData=[] #未指定种子（即按系统时间），生成序列

    for i in range(N):
        seedData.append(dataBySeed(seed,num,M))

    for i in range(N):
        sysData.append(dataBySys(num,M))

    print('seedData:',seedData)
    print('sysData:',sysData)

    # 注意，生成时不能在一个for循环中，否则sysData默认也使用指定的种子，生成相同的序列，例如，如下：
    for i in range(N):
        seedData.append(dataBySeed(seed, num, M))
        sysData.append(dataBySys(num, M))