# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: assistants.py
@time: 2020/7/26 10:31
@description:
"""


from node import PDNode
import os
import shutil


def compute_parameter_aided_Parameter(terminal, berth, block, vessel, container):

    # 计算输出干线泊位fcsberth、支线泊位barberth
    fcsberth = []  # 干线泊位ID列表
    barberth = []  # 支线泊位ID列表
    for b in berth.keys():
        if berth[b][2] == 0:  # b为干线泊位
            fcsberth.append(berth[b][0])
        else:
            barberth.append(berth[b][0])

    # 计算输出c1v，表示一程船为v的集合
    c1v = {}  # 字典结构 一程船ID：一程船ID，[对应中转箱列表]
    for v in vessel.keys():
        containers = []
        for c in container.keys():
            if container[c][1] == vessel[v][0]:
                containers.append(c)
        c1v[v] = containers

    # 计算输出c2v，表示二程船为v的集合
    c2v = {}  # 字典结构 二程船ID：二程船ID，[对应中转箱列表]
    for v in vessel.keys():
        containers = []
        for c in container.keys():
            if container[c][2] == vessel[v][0]:
                containers.append(c)
        c2v[v] = containers

    # 计算输出mb，表示泊位b所在码头的箱区
    mb_zc = {}  # 泊位b所在码头供装船使用的箱区
    mb_xc = {}  # 泊位b所在码头供卸船使用的箱区
    for b in berth.keys():
        zc = []
        xc = []
        for m in block.keys():
            if berth[b][1] == block[m][1] and block[m][4]==0:
                zc.append(m)
            if berth[b][1] == block[m][1] and block[m][4]==1:
                xc.append(m)
        mb_zc[b] = zc
        mb_xc[b] = xc

                
    
    
    # 计算输出mb，表示泊位b后方的两个箱区，两个箱区依次为装船箱区，卸船箱区
    '''
    mb = {}  # 字典结构 berthID：[泊位b后方的装船箱区ID，卸船箱区ID]
    for t in terminal.keys():

        berthlist = []
        blocklist = []
        for b in berth.keys():
            if berth[b][1] == t:
                berthlist.append(b)
        for m in block.keys():
            if block[m][1] == t:
                blocklist.append(m)

        count = 0
        for b in berthlist:
            backblock = []  # 泊位b后方的箱区
            for m in blocklist[count:count + 2]:
                backblock.append(m)
            mb[b] = backblock
            count += 2
    '''
    # 计算输出干线船和支线船
    fcsvessel = []  # 干线泊位ID列表
    barvessel = []  # 支线泊位ID列表
    for v in vessel.keys():
        if vessel[v][3] == 0:  # v为干线船
            fcsvessel.append(vessel[v][0])
        else:  # v为支线船
            barvessel.append(vessel[v][0])
    

    return fcsberth, barberth, c1v, c2v, mb_zc,mb_xc,fcsvessel,barvessel


def build_pd_pair(Request, DistanceMatrix, TimeMatrix, TaskList_BlockID, TimeWindow, ServiceTime, ContainerID, TaskList):
    """根据读取的信息，建立PD-pair类对象
        并检查每对PD点对的有效性"""

    # 使用zip()函数，将TaskList和ContainerID同时遍历，并生成一个字典
    TaskList_ContainerID = {}
    for t, c in zip(TaskList, ContainerID):
        TaskList_ContainerID[t] = c

    pd_nodes = []
    for n in Request.keys():
        distance = DistanceMatrix[Request[n][0], Request[n][1]]
        time = TimeMatrix[Request[n][0], Request[n][1]]
        pd_node = PDNode(n,
                         Request[n][0], Request[n][1],
                         distance, time,
                         TimeWindow[Request[n][0]], TimeWindow[Request[n][1]],
                         ServiceTime[Request[n][0]], ServiceTime[Request[n][1]],
                         TaskList_ContainerID[Request[n][0]],
                         TaskList_BlockID[Request[n][0]], TaskList_BlockID[Request[n][1]])
        error_list = []
        if pd_node.check_feasible() == "error1": # 如果某对PD点对不可行，那么忽略，并抛出异常
            # print("PD点对[%s,%s]：时间窗异常，取货点左时间窗>=送货点的右时间窗" % (Request[n][0], Request[n][1]))
            error_list.append('error1')
            # continue
        elif pd_node.check_feasible() == "error2":
            # print("PD点对[%s,%s]：时间窗异常，取货点左时间窗+取货点服务时间+送货点服务时间+取送货点之间的行驶时间>=送货点的右时间窗" % (Request[n][0], Request[n][1]))
            error_list.append('error2')
        # else:
            # print("PD点对[%s,%s]：时间窗正常" % (Request[n][0], Request[n][1]))
        
        pd_nodes.append(pd_node)
        
        if len(error_list) == 0:
            continue
        else:
            print('有%s个PD点对的时间窗不正常' % len(error_list)) 

    return pd_nodes


def cal_pd_distance_time(pd_nodes, DistanceMatrix, TimeMatrix):
    """构建PD点对之间的车辆行驶距离，和车辆行驶时间：
        比如车辆从 PD1 --> PD2，那么距离为DistanceMatrix[D1,P1]，时间为TimeMatrix[D1,P1]
    """
    PD_Travel_Distance = {}
    PD_Travel_Time = {}
    for pd_node1 in pd_nodes:
        for pd_node2 in pd_nodes:
            if pd_node1 != pd_node2:
                PD_Travel_Distance[pd_node1, pd_node2] = DistanceMatrix[pd_node1.d_id, pd_node2.p_id]
                PD_Travel_Time[pd_node1, pd_node2] = TimeMatrix[pd_node1.d_id, pd_node2.p_id]
    return PD_Travel_Distance, PD_Travel_Time


def cal_model_obj(vehicles, alpha=1, beta=0.1, gamma=0.001):
    """计算两阶段模型的目标函数。
       对于模对于模型一某一可行解下模型二的可行解，其计算公式为：
       模型目标函数值 = α * 时间窗违背成本 + β * 车辆启用成本 + γ * 车辆行驶成本
       其中α,β,γ为三种成本的系数，且要保证α≫β≫γ
       同时，要选取合适的费用系数
       时间窗违背成本如何计算，1min=10元？
       规划期内启用一辆车要多少钱？500元？
       行驶成本每公里多少？1元=1km？
    """
    
    total_violate_soft_time = 0
    total_travel_distance = 0
    for veh in vehicles:
        total_violate_soft_time += veh.total_soft_violate_time
        total_travel_distance += veh.distance
        
    model_obj = alpha*10*total_violate_soft_time + beta*500*len(vehicles) + gamma*1*(total_travel_distance / 1000)
    
    # model_obj_shrink = model_obj / 100000  # 为了不让目标函数值过大，同一缩小尺度
    
    return model_obj

def clear_dir():
    filelist=[]
    rootdir="./level1_solution/"                       #选取删除文件夹的路径,最终结果删除img文件夹
    filelist=os.listdir(rootdir)                #列出该目录下的所有文件名
    for f in filelist:
        filepath = os.path.join( rootdir, f )   #将文件名映射成绝对路劲
        if os.path.isfile(filepath):            #判断该文件是否为文件或者文件夹
            os.remove(filepath)                 #若为文件，则直接删除
            # print(str(filepath)+" removed!")
        elif os.path.isdir(filepath):
            shutil.rmtree(filepath,True)        #若为文件夹，则删除该文件夹及文件夹内所有文件
            # print("dir "+str(filepath)+" removed!")
    
    rootdir="./level2_initial_info/"                       #选取删除文件夹的路径,最终结果删除img文件夹
    filelist=os.listdir(rootdir)                #列出该目录下的所有文件名
    for f in filelist:
        filepath = os.path.join( rootdir, f )   #将文件名映射成绝对路劲
        if os.path.isfile(filepath):            #判断该文件是否为文件或者文件夹
            os.remove(filepath)                 #若为文件，则直接删除
            # print(str(filepath)+" removed!")
        elif os.path.isdir(filepath):
            shutil.rmtree(filepath,True)        #若为文件夹，则删除该文件夹及文件夹内所有文件
            # print("dir "+str(filepath)+" removed!")
    
    rootdir="./level2_solution/"                       #选取删除文件夹的路径,最终结果删除img文件夹
    filelist=os.listdir(rootdir)                #列出该目录下的所有文件名
    for f in filelist:
        filepath = os.path.join( rootdir, f )   #将文件名映射成绝对路劲
        if os.path.isfile(filepath):            #判断该文件是否为文件或者文件夹
            os.remove(filepath)                 #若为文件，则直接删除
            # print(str(filepath)+" removed!")
        elif os.path.isdir(filepath):
            shutil.rmtree(filepath,True)        #若为文件夹，则删除该文件夹及文件夹内所有文件
            # print("dir "+str(filepath)+" removed!")
    
    
    if len(filelist) != 0:
        print('清空文件夹成功')


#def check_vehicle_route_feasible(vehicles):
    # 检查某个车辆路径是否可行，如果有一个车辆的路径违背了硬时间窗约束，那么则不可行