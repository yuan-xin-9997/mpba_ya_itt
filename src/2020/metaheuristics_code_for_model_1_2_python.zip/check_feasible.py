# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: check_feasible.py
@time: 2020/7/26 10:34
@description:
"""

from gurobipy import GRB


def check_model_feasible(model):
    """  检查模型是否可行.

    具体描述：检查模型是否可行，如果不可行，则计算其IIS，并打印IIS的约束名称.
    """

    if model.status == GRB.INFEASIBLE:
        print('Optimization was stopped with status %d' % model.status)
        print('Model is infeasible')
        # do IIS, find infeasible constraints
        model.computeIIS()
        model.write("%s_bygurobi_IIS.ilp" % model.name)
        model.write("%s_bygurobi_IIS.lp" % model.name)
        for c in model.getConstrs():
            if c.IISConstr:
                print('%s' % c.constrName)
    return