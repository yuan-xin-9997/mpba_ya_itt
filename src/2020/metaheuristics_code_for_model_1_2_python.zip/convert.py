# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: convert.py
@time: 2020/7/25 20:28
"""

from gurobipy import *
from gurobipy import GRB


# 转换为符合论文需要的格式，而不是符合Li&Limit benchmark格式的数据
def level1_to_level2(terminal,berth,block,vessel,container,K,Q,S,SchedulingDuration,solu_number_list, model_level1,mb_zc,mb_xc):
    """  根据第一阶段的决策结果，转化为第二阶段的初始信息输入，并生成可供第二阶段读取的txt文件.

    具体描述：

    转化为第二阶段的数据示例：
    6	1	500
    -1	0	0	2880	0	0	0	-1	-1
    1	1	779	2880	20	0	2	81	0
    2	-1	0	2466	20	1	0	84	0
    3	1	283	2880	20	0	4	23	1
    4	-1	0	2466	20	3	0	84	1
    5	1	2166	2880	20	0	6	81	2
    6	-1	0	2145	20	5	0	17	2
    7	1	2166	2880	20	0	8	81	3
    8	-1	0	2145	20	7	0	17	3
    9	1	779	2880	20	0	10	81	4
    10	-1	0	2466	20	9	0	84	4
    11	1	2019	2880	20	0	12	84	5
    12	-1	0	2466	20	11	0	84	5
    13	1	2019	2880	20	0	14	84	6
    14	-1	0	2057	20	13	0	81	6
    15	1	2166	2880	20	0	16	81	7
    16	-1	0	2057	20	15	0	81	7
    17	1	779	2880	20	0	18	81	8
    18	-1	0	2466	20	17	0	84	8
    19	1	645	2880	20	0	20	17	9
    20	-1	0	525	20	19	0	23	9
    -2	0	0	2880	0	0	0	-1	-1

    说明
    第一行为：可使用的车辆数量K、每辆车的载量Q、车辆行驶速度S
    第二行为开始depot，最后一行为结束depot，两行只是TN不同，其他均相同，为了建模需要生成，其中开始depot的TN/BlockID为-1，结束depot的TN/BlockID为-2
    第三行到倒数第二行为P和D点：每列一次为
    TN    D   ET    LT     ST   PI    DI    BlockID    ContainerID
    从第三行开始，每两行为一个中转箱的取货和送货任务的信息，比如第三行是中转箱0的取货任务信息，第四行是中转箱0的送货任务信息，且按中转箱的ID依次排列
    假定每个取送货任务的服务时间均为20分钟
    """

    yvb, U, V = model_level1.__data

    for e in solu_number_list:

        # Solution Pool 编号
        model_level1.setParam(GRB.Param.SolutionNumber, e)

        quay_time = 20 # 中转箱从船到存放的箱区，或从存放的箱区到船，所花费的岸桥时间、内集卡时间、场桥时间

        # 任务编号，Task Number
        TN = [0] * (2 * len(container) + 2)  # 长度为 2个depot+2*中转箱container的数量
        TN[0] = 0  # 开始depot，其TN,TaskNo任务号为0
        TN[-1] = 2 * len(container) + 1  # 结束depot，其TN,TaskNo任务号为2 * len(container) + 1
        for i in range(1, len(TN) - 1):  # P和D任务的TN依次为1,2,3,...
            TN[i] = i

        # Demand
        Demand = [0] * (2 * len(container) + 2)
        for j in range(1, len(TN) - 1):
            if j % 2 == 1:  # 取箱任务P
                Demand[j] = 1
            if j % 2 == 0:  # 送箱任务D
                Demand[j] = -1

        # Earliest time and Latest time
        Et = [0] * (2 * len(container) + 2)
        Lt = [SchedulingDuration] * (2 * len(container) + 2)
        countcontainerid = 0
        for j in range(1, len(TN) - 1):
            if j % 2 == 1:  # 取箱任务P
                containerid = container[countcontainerid][0]
                v1 = container[containerid][1]
                Et[j] = vessel[v1][1] + quay_time  # 取货任务的开始时间窗为其中转箱对应一程船到港之后+quay_time
                Lt[j] = SchedulingDuration  # 结束时间窗为规划期
                countcontainerid += 1
        countcontainerid = 0
        for j in range(1, len(TN) - 1):
            if j % 2 == 0:  # 送箱任务D
                containerid = container[countcontainerid][0]  # 送货任务的开始时间窗为0
                v2 = container[containerid][2]  # 送货任务的结束时间窗为其中转箱对应的二程船离港-quay_time
                Et[j] = 0
                Lt[j] = vessel[v2][2] - quay_time
                countcontainerid += 1

        # Service time
        St = [0] * (2 * len(container) + 2)  # ITT集卡到某个箱区取箱或送箱所花费的时间
        for j in range(1, len(TN) - 1):
            St[j] = 10

        # Pickup Index,Delivey Index
        Pi = [0] * (2 * len(container) + 2)
        Di = [0] * (2 * len(container) + 2)
        for j in range(1, len(TN) - 1):
            if j % 2 == 1:  # 取箱任务P
                Pi[j] = 0
                Di[j] = j + 1
            if j % 2 == 0:  # 送箱任务D
                Di[j] = 0
                Pi[j] = j - 1

        # BlockID（即任务对应的箱区，比如这是一个取货任务，那么其取货对应的箱区ID是什么，反之送货任务对应的箱区ID是什么）
        BI = [-1] * (2 * len(container) + 2)  # 开始depot的箱区识别号为-1
        countbi = 1
        for c in container.keys():
            for b in berth.keys():
                for m in mb_xc[b]:
                    if U[c, b, m].xn > .9:
                        BI[countbi] = block[m][0]
                        countbi += 1
            for b in berth.keys():
                for m in mb_zc[b]:
                    if V[c, m, b].xn > .9:
                        BI[countbi] = block[m][0]
                        countbi += 1
        BI[-1] = -2  # 结束depot的箱区识别号为-2

        # ContainerID（即某一任务对应的中转箱的ID，比如取货任务，那么其取货的中转箱的ID）
        ContainerID = [-1] * (2 * len(container) + 2)  # 两个depot的的中转箱ID为-1
        countci = 1
        for c in container.keys():
            for b in berth.keys():
                for m in mb_xc[b]:
                    if U[c, b, m].xn > .9:
                        ContainerID[countci] = container[c][0]
                        countci += 1
            for b in berth.keys():
                for m in mb_zc[b]:
                    if V[c, m, b].xn > .9:
                        ContainerID[countci] = container[c][0]
                        countci += 1

        ## 写入操作
        f = open('./level2_initial_info/leve1_solution_%s.txt' % e, 'w')

        nlines = 2 * len(container) + 2

        # 第0行
        line0 = [K, Q, S]
        for j in range(len(line0)):
            if j != (len(line0) - 1):
                f.write(str(line0[j]))
                f.write('\t')
            else:
                f.write(str(line0[j]))
        f.write('\n')

        # 第1行
        line1 = []
        line1.append(TN[0])
        line1.append(Demand[0])
        line1.append(Et[0])
        line1.append(Lt[0])
        line1.append(St[0])
        line1.append(Pi[0])
        line1.append(Di[0])
        line1.append(BI[0])
        line1.append(ContainerID[0])
        for j in range(len(line1)):
            if j != (len(line1) - 1):
                f.write(str(line1[j]))
                f.write('\t')
            else:
                f.write(str(line1[j]))
        f.write('\n')

        # 第2-2_行
        for j in range(1, nlines - 1):
            line_2_2 = []
            line_2_2.append(TN[j])
            line_2_2.append(Demand[j])
            line_2_2.append(Et[j])
            line_2_2.append(Lt[j])
            line_2_2.append(St[j])
            line_2_2.append(Pi[j])
            line_2_2.append(Di[j])
            line_2_2.append(BI[j])
            line_2_2.append(ContainerID[j])
            for j in range(len(line_2_2)):
                if j != (len(line_2_2) - 1):
                    f.write(str(line_2_2[j]))
                    f.write('\t')
                else:
                    f.write(str(line_2_2[j]))
            f.write('\n')

        # 最后1行
        line_1 = []
        line_1.append(TN[-1])
        line_1.append(Demand[-1])
        line_1.append(Et[-1])
        line_1.append(Lt[-1])
        line_1.append(St[-1])
        line_1.append(Pi[-1])
        line_1.append(Di[-1])
        line_1.append(BI[-1])
        line_1.append(ContainerID[-1])
        for j in range(len(line_1)):
            if j != (len(line_1) - 1):
                f.write(str(line_1[j]))
                f.write('\t')
            else:
                f.write(str(line_1[j]))

        # 关闭文件
        f.close()

    return