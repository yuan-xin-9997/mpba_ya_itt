# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: distance_time_matrix.py
@time: 2020/7/25 20:32
"""

import math


def calculate_manhattan_distance(x1, y1, x2, y2):
    """  计算Manhattan距离.
    具体描述：计算两点(x1, y1), (x2, y2)之间的Manhattan距离.
    """
    return math.fabs(x2 - x1) + math.fabs(y2 - y1)


def construct_distance_matrix(block, terminalgatedistance, TaskList, BlockID): # (task和task所代表的箱区之间的距离）
    """  构造depot、箱区之间的距离矩阵.

    具体描述：
    构建箱区之间的距离矩阵，构建适合论文中需要的距离矩阵。
    如果是同一码头内部的箱区，则箱区之间的距离仅为曼哈顿距离；
    如果是不同码头之间的箱区，则箱区之间的距离为箱区至道口的曼哈顿距离+码头道口间的道路距离；
    任何一个箱区到depot的距离假设为1000m；
    开始的depot键为-1，结束的depot键为-2，箱区的键依次为0,1,2,...,
    """

    # 每个码头道口到箱区的距离
    gatecoodinates = {0:(0,1126,735), # 每个码头gate的坐标，字典结构 码头ID：码头ID，gate'x坐标，gate'y坐标
                      1:(2,1337,779),
                      2:(3,1151,550),
                      3:(4,800,600)} 
    
    
    # 箱区和箱区之间的距离
    BlockDistanceMatrix = {}
    for i in block.keys():
        for j in block.keys():
            if i == j:
                BlockDistanceMatrix[i,j] = 0
            elif j > i:
                if block[i][1] == block[j][1]: # 箱区i和箱区j属于同一个码头
                    BlockDistanceMatrix[i,j] = calculate_manhattan_distance(block[i][2],block[i][3],block[j][2],block[j][3])
                    BlockDistanceMatrix[j,i] = BlockDistanceMatrix[i,j]
                else: # 箱区i和箱区j不属于同一个码头：箱区至道口的距离+码头道口间的道路距离
                    gate_block = calculate_manhattan_distance(block[i][2],block[i][3],gatecoodinates[block[i][1]][1],gatecoodinates[block[i][1]][2]) + \
                                 calculate_manhattan_distance(block[j][2],block[j][3],gatecoodinates[block[j][1]][1],gatecoodinates[block[j][1]][2])
                    BlockDistanceMatrix[i,j] = gate_block + terminalgatedistance[block[i][1],block[j][1]]
                    BlockDistanceMatrix[j,i] = gate_block + terminalgatedistance[block[j][1],block[i][1]]
                    
    
    # 开始depot、结束depot、箱区之间的距离
    BlockDistanceMatrix[-1, -2] = 0  # 开始depot（对应箱区-1）和结束depot（对应箱区-2）之间的距离为0
    for b in block.keys(): # 假设开始depot和结束depot位于四个码头中部位置，计算depot和箱区之间的距离
        if block[b][1] == 0: # 洋一二
            gate_block = calculate_manhattan_distance(block[b][2],block[b][3],gatecoodinates[block[b][1]][1],gatecoodinates[block[b][1]][2])
            BlockDistanceMatrix[-1, b] = 764 + gate_block # depot到洋一二道口+道口到箱区
            BlockDistanceMatrix[b, -2] = 764 + gate_block
        if block[b][1] == 1: # 洋三
            gate_block = calculate_manhattan_distance(block[b][2],block[b][3],gatecoodinates[block[b][1]][1],gatecoodinates[block[b][1]][2])
            BlockDistanceMatrix[-1, b] = 3160 + gate_block
            BlockDistanceMatrix[b, -2] = 3160 + gate_block
        if block[b][1] == 2: # 洋四
            gate_block = calculate_manhattan_distance(block[b][2],block[b][3],gatecoodinates[block[b][1]][1],gatecoodinates[block[b][1]][2])
            BlockDistanceMatrix[-1, b] = 3100 + gate_block
            BlockDistanceMatrix[b, -2] = 3100 + gate_block
        if block[b][1] == 3: # 洋五
            gate_block = calculate_manhattan_distance(block[b][2],block[b][3],gatecoodinates[block[b][1]][1],gatecoodinates[block[b][1]][2])
            BlockDistanceMatrix[-1, b] = 4078 + gate_block
            BlockDistanceMatrix[b, -2] = 4078 + gate_block

    # 使用zip()函数，将TaskList和BlockID同时遍历，并生成一个字典
    TaskList_BlockID = {}
    '''
    for t, b in zip(TaskList, BlockID):
        TaskList_BlockID[t] = b
    '''
    for i in range(len(TaskList)):
        TaskList_BlockID[TaskList[i]]=BlockID[i]
    
    # Tasklist和TaskList中任务之间对应的距离（每一个任务task都是一个虚拟的点）
    DistanceMatrix = {}
    for i in TaskList:
        if i == TaskList[0]:
            for j in TaskList[1:]:
                DistanceMatrix[i, j] = BlockDistanceMatrix[TaskList_BlockID[i], TaskList_BlockID[j]]
        elif i != TaskList[-1]:  # task i 不是开始depot,也不是结束depot
            for j in TaskList[1:]:
                if i != j:
                    DistanceMatrix[i, j] = BlockDistanceMatrix[TaskList_BlockID[i], TaskList_BlockID[j]]

    # 获取字典DistanceMatrix中最大的值
    key = max(DistanceMatrix, key=DistanceMatrix.get)
    LongestDistance = DistanceMatrix[key]

    return DistanceMatrix,TaskList_BlockID,LongestDistance


# 计算时间矩阵：由于算法不是默认一下子使用所有车辆，故计算时间矩阵需要大改
# 如果假设车辆的速度均相同，那么也可以使用

def construct_time_matrix(DistanceMatrix, speed):
    """  构造通行时间矩阵.

    具体描述：对于车辆k，若其速度为sk，点i到点j的距离为dij，那么其从点i行驶到点j所用的时间tijk=dij/sk
    """
    TimeMatrix = {}
    for (i, j) in DistanceMatrix:
        TimeMatrix[i, j] = DistanceMatrix[i, j] / speed

    return TimeMatrix
