# -*- coding: utf-8 -*-
"""
Created on Sat Aug  1 20:34:03 2020

@author: AtticusYuan
"""

import time

from gurobipy import GRB
from gurobipy import *

#from information_input_v2_1 import make_level1_data  # 算例一
#from information_input_v2_1 import read_level2_data  # 算例一
from information_input_v2_2 import make_level1_data # 算例二
from information_input_v2_2 import read_level2_data # 算例二

from distance_time_matrix import construct_distance_matrix
from distance_time_matrix import construct_time_matrix
from check_feasible import check_model_feasible
from assistants import compute_parameter_aided_Parameter
from assistants import build_pd_pair
# from assistants import cal_pd_distance_time
from assistants import clear_dir
from convert import level1_to_level2

from model_level1_by_gurobi import bulid_cp_model
from solomon_insertion_for_model_level2 import solomon_i1
from tabu_search_for_model_level2 import tabu_search

from write_solution import write_level1_solution


if __name__ == '__main__':

    start = time.time()  # 程序开始时间

    ### 阶段一读取数据与辅助工作（阶段二的数据已经隐含在这里面了）

    level1_start_time = time.time()
    
    ## 数据读取
    vessel_number = 20  # instance船舶数量
    container_number = 50  # instance中转箱的数量
    terminal,berth,block,vessel,container,K,Q,S,SchedulingDuration,terminalgatedistance = make_level1_data(vessel_number,container_number)  # 船舶数量，中转箱数量，可用集卡数量
    clear_dir() # 清空文件夹
    
    ## 计算阶段一的辅助参数
    fcsberth, barberth, c1v, c2v, mb_zc,mb_xc,fcsvessel,barvessel = compute_parameter_aided_Parameter(terminal,berth,block,vessel,container)

    ## 第一阶段模型建立（Gurobi）
    model_level1 = bulid_cp_model(terminal,berth,block,vessel,container,fcsberth,barberth,c1v,c2v,mb_zc,mb_xc)

    ## 第一阶段Gurobi模型Solution Pool参数设置
    # 限制模型收集多少可行解的数量
    # level1_solution_number = len(vessel) * len(container) * len(berth) * len(block)  # 数字过大
    #level1_solution_number = len(container) * len(block)  # 不准确
    # level1_solution_number = comb(len(fcsberth),len(fcsvessel)) * comb(len(barberth),len(barvessel))  # 数字过大
    # level1_solution_number = comb(len(fcsberth),len(fcsvessel)) * comb(len(barberth),len(barvessel))  # 规模大会有错误
    # level1_solution_number = len(fcsberth) * len(fcsvessel) * len(barberth) * len(barvessel)  # instance数较大的时候再用
    level1_solution_number = 200000
    model_level1.setParam(GRB.Param.PoolSolutions, int(level1_solution_number))
    # 设置解池搜索模式为2，即 the MIP to do a systematic search for the n best solutions（n为设定的要收集的可行解的数量）
    model_level1.setParam(GRB.Param.PoolSearchMode, 2)
    # 设置收集的可行解的值与最优值的gap值，Limit the search space by setting a gap for the worst possible solution that will be accepted
    model_level1.setParam(GRB.Param.PoolGap, 1)
    # 设置MIPFocus
    model_level1.setParam(GRB.Param.MIPFocus,1)  # 侧重快速找到可行解

    ## 第一阶段模型求解
    model_level1.optimize()

    ## 检验第一阶段模型是否可行，如果不可行，则计算IIS，并写入到ilp文件，并打印IIS约束的名称
    check_model_feasible(model_level1)

    ## 输出第一阶段收集的可行解的数量，Print number of solutions stored
    nSolutions = model_level1.SolCount
    yvb,U,V = model_level1.__data

    ## 将第一阶段模型的所有可行分配方案写入到文件当中（由于可行分配方案过大，这一步，以一定规则选择性的将可行解写入文件中）
    solu_number_list,level1_solu_number = write_level1_solution(vessel, container, berth, mb_zc,mb_xc, model_level1, nSolutions, yvb, U, V)
    print('正在将第一阶段模型的分配方案写入到文件夹中，请稍等……')
    level1_end_time = time.time()

    ## 阶段一与阶段二转化（将第一阶段的每一个可行分配方案，转化为第二阶段可读的初始信息）
    level1_to_level2(terminal,berth,block,vessel,container,K,Q,S,SchedulingDuration,solu_number_list, model_level1,mb_zc,mb_xc)
    print('正在将第一阶段模型的分配方案转化为第二阶段初始信息，并写入到文件夹中，请稍等……')
    
    ## 阶段一的每一个可行解输出为供阶段二可读的数据文件，并调用阶段二的模型进行求解
    level2_start_time = time.time()
    Global_Best_Total_Cost = 1e10  # 阶段二的目标函数，α*时间窗违背成本+β*车辆启用成本+γ*车辆行驶成本，其中α≫β≫γ，依次为1000,100,1
    Best_level1_solution = -1  # 最好的第一阶段分配方案
    tabu_improve_ratio = 0
    f = open("两阶段模型求解的最终结果.txt", 'w')
    f.write(str("===============以下为在instance=[船舶数量，中转箱数量]=[%s,%s]的最终求解结果===============" % (vessel_number,container_number)))
    f.write('\n')
    for i in solu_number_list:
        
#        if i != 0:  # 先暂时求一个解
#            break
        print("")
        print("====================第一阶段解 %s 对应的第二阶段模型求解中====================" % i)

        ## 数据读取

        # 数据路径
        DataPath = "./level2_initial_info/leve1_solution_%s.txt" % i

        # 读取第二阶段数据（建立Node类对象）
        max_vehicle,capacity,speed,nodes,Demand,TimeWindow,ServiceTime,Request,BlockID,ContainerID,TaskNumber,TaskList = read_level2_data(DataPath)
        capacity_list = [capacity] * max_vehicle

        ## 辅助计算

        # 构建Task与Task之间的距离矩阵
        DistanceMatrix,TaskList_BlockID,LongestDistance = construct_distance_matrix(block, terminalgatedistance, TaskList, BlockID)

        # 构建Task与Task之间的通行时间矩阵
        TimeMatrix = construct_time_matrix(DistanceMatrix, speed)

        # 建立PD-pair类对象
        pd_nodes = build_pd_pair(Request, DistanceMatrix, TimeMatrix, TaskList_BlockID, TimeWindow, ServiceTime, ContainerID, TaskList)

        # 构建PD点对之间的通行距离矩阵和通行时间矩阵（暂时没有用到）
        # PD_Travel_Distance, PD_Travel_Time = cal_pd_distance_time(pd_nodes, DistanceMatrix, TimeMatrix)

        ## Solomon插入算法构造初始路径
        sol_start_time = time.time()
        sol_vehicles, sol_obj = solomon_i1(TaskList, nodes, max_vehicle, pd_nodes, capacity_list, speed, DistanceMatrix)
        sol_end_time = time.time()
        
        ## 将Solomon初始解输入到TabuSearch算法当中继续求解
        tabu_start_time = time.time()
        tabu_best_vehs, tabu_best_obj = tabu_search(sol_vehicles, pd_nodes)
        tabu_end_time = time.time()
        
        # 将结果写入到文件中
        Solution_Path = "./level2_solution/leve1_solution_%s.txt" % i  # 路径
        h = open(Solution_Path, 'w')
        total_travel_distance = 0
        total_violate_soft_time = 0
        total_violate_hard_time = 0
        h.write("===车辆的信息===\n")
        for veh in tabu_best_vehs:
            h.write(str('-车辆 %s 的信息-：\n' % veh.v_id))
            h.write(str('违背硬时间窗：%s 分钟\n' % veh.total_hard_violate_time))
            h.write(str('违背软时间窗：%s 分钟\n' % veh.total_soft_violate_time))
            h.write(str('行驶距离：%s 米\n' % veh.distance))
            h.write(str('路径：%s \n' % veh.pd_route))
            h.write(str('开始服务时间：%s \n' % veh.start_time))
            h.write(str('等待时间：%s \n' % veh.wait_time))
            total_travel_distance += veh.distance
            total_violate_soft_time += veh.total_soft_violate_time
            total_violate_hard_time += veh.total_hard_violate_time
        h.write('\n')
        h.write(str("%s辆车一共违背的硬时间窗：%s 分钟 \n" % (len(tabu_best_vehs),total_violate_hard_time)))   
        h.write(str("%s辆车一共违背的软时间窗：%s 分钟\n" % (len(tabu_best_vehs),total_violate_soft_time)))
        h.write(str("总共使用的车辆数量：%s 辆\n" % len(tabu_best_vehs)))
        h.write(str("%s辆车一共行驶的距离：%s 米\n" % (len(tabu_best_vehs),total_travel_distance)))
        
        # α、β、γ的系数依次为1000,100,1，每违背一分钟时间窗惩罚10元，每辆车的启用成本为500元，车辆行驶成本每公里1元
        # Total_Cost = cal_model_obj(vehicles)
        h.write('\n')
        h.write(str("阶段二模型的目标函数值为：%s \n" % tabu_best_obj))
        h.write(str("禁忌搜索提升目标函数值：%s \n" % (sol_obj - tabu_best_obj)))
        h.write(str("禁忌搜索提升目标函数值比例：%s \n" % (1 - tabu_best_obj/sol_obj)))
        h.write(str("Solomon插入算法运行时间：%s 秒\n" % (sol_end_time - sol_start_time)))
        h.write(str("TabuSearch算法运行时间：%s 秒\n" % (tabu_end_time - tabu_start_time)))
        print("Solomon插入算法运行时间：%s 秒\n" % (sol_end_time - sol_start_time))
        print("TabuSearch算法运行时间：%s 秒\n" % (tabu_end_time - tabu_start_time))
        tabu_improve_ratio += (1 - tabu_best_obj/sol_obj)
        
        # 判断（要将三种成本换成人民币来算）
        if tabu_best_obj < Global_Best_Total_Cost:
            Global_Best_Total_Cost = tabu_best_obj
            Best_level1_solution = i    
    level2_end_time = time.time()
    
    ### 两阶段最终结果  
    f.write(str('共计算第一阶段模型可行的泊位分配和箱区选位的方案数量:%s \n' % level1_solu_number))
    f.write(str("最好的第一阶段分配方案：level1_solution_%s \n" % Best_level1_solution))
    f.write(str("对应的第二阶段的成本为：%s \n" % Global_Best_Total_Cost))
    f.write(str("禁忌搜索平均提升的值为：%s \n" % (tabu_improve_ratio / level1_solu_number)))
    
    ### 计算程序运行时间
    f.write(str('第一阶段模型程序运行时间（Gurobi）：%s 秒 \n' % (level1_end_time - level1_start_time)))
    f.write(str('第二阶段模型程序运行时间（改造的Solomon插入算法+禁忌搜索）：%s 秒 \n' % (level2_end_time - level2_start_time)))
    end = time.time()
    f.write(str('整个程序运行时间：%s 秒 \n' % (end - start)))
    
    f.close()