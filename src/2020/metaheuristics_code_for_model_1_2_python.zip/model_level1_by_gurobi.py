# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: model_level1_by_gurobi.py
@time: 2020/7/25 20:27
"""

from gurobipy import *
from gurobipy import GRB
import random

def bulid_cp_model(terminal,berth,block,vessel,container,fcsberth,barberth,c1v,c2v,mb_zc,mb_xc):
    """  建立模型.

    具体描述：建立第一阶段的模型，本质是一个0-1约束规划模型.
    """

    # 创建模型
    model_level1 = Model("model_level1_cp")

    # 创建变量

    # 变量下标存放字典
    yvbindex = {}  # 存储变量yvb的下标vb
    Uindex = {}  # 存储变量Ucbm的下标cbm
    Vindex = {}  # 存储变量Vcbm的下标cbm
    #yvindex = {}  # 存储变量yv的下标v，用来线性化的变量
    for v in vessel.keys():
        #yvindex[v] = 0
        for b in berth.keys():
            yvbindex[v, b] = 0
    for c in container.keys():
        for b in berth.keys():
#            mb_xc.pop(random.choice([0,1]))
#            mb_zc.pop(random.choice([0,1]))
            for m in mb_xc[b]:
                Uindex[c, b, m] = 0
            for m in mb_zc[b]:
                Vindex[c, m, b] = 0

    # 创建变量
    yvb = model_level1.addVars(yvbindex.keys(), vtype=GRB.BINARY, name="yvb")
    U = model_level1.addVars(Uindex.keys(), vtype=GRB.BINARY, name="U")
    V = model_level1.addVars(Vindex.keys(), vtype=GRB.BINARY, name="V")
    #yv = model_level1.addVars(yvindex.keys(),vtype=GRB.BINARY,name="yv")

    ## 创建约束

    # 约束（1）所有的船舶必须选择一个泊位进行停泊，且仅停泊一次，（干线船只能停在干线泊位上，支线船只能停在支线泊位上）
    for v in vessel.keys():
        if vessel[v][3] == 0:  # 如果船舶v是干线船，那么只能停在干线泊位上
            model_level1.addConstr(sum(yvb[v, b] for b in fcsberth) == 1, name="约束（1）：船%s必须停泊在一个泊位上" % v)
            for b in barberth:  # 那么其不能停在支线码头
                model_level1.addConstr(yvb[v, b] == 0)
        elif vessel[v][3] == 1:  # 如果船舶v是支线船，那么只能停在支线泊位上
            model_level1.addConstr(sum(yvb[v, b] for b in barberth) == 1, name="约束（1）：船%s必须停泊在一个泊位上" % v)
            for b in fcsberth:  # 那么其不能停在干线码头
                model_level1.addConstr(yvb[v, b] == 0)
        # model_level1.addConstr(yvb.sum(v,'*') == 1,name="约束（1）：船%s必须停泊在一个泊位上" % v)  # 星号*的用法，如果不分干支线船

    # 约束（2）每个有时间靠泊和离泊时间重叠的两艘船v1,v2不能停泊在同一个泊位上
    for b in berth.keys():
        for v1 in vessel.keys():
            for v2 in vessel.keys():
                if v1 != v2:
                    '''
                    if vessel[v1][1] == vessel[v2][1]:
                        # 对乘积式进行线性化
                        #model_level1.addConstr(0<=yvb[v1, b])
                        #model_level1.addConstr(0<=yvb[v2, b])
                        model_level1.addConstr(yvb[v1, b]+yvb[v2, b]<=1,name="约束(2.1)：靠泊时间相同的船 %s 和 船 %s 不能同时在泊位 %s 停泊" % (
                                               v1, v2, b))
                        # 乘积式约束
#                        model_level1.addConstr(yvb[v1, b] * yvb[v2, b] == 0,
#                                               name="约束(2.1)：靠泊时间相同的船 %s 和 船 %s 不能同时在泊位 %s 停泊" % (
#                                               v1, v2, b))  # 约束（3.1），那就只有将其转换为二次约束了
                    '''
                    if (vessel[v1][1] <= vessel[v2][1]) and (vessel[v1][2] >= vessel[v2][1]):
                        model_level1.addConstr(yvb[v1, b]+yvb[v2, b]<=1,name="约束(2.2)：船 %s 船 %s 泊位 %s 满足约束(2.2) " % (v1, v2, b))
#                        model_level1.addConstr(yvb[v1, b] * yvb[v2, b] == 0,
#                                               name="约束(2.2)：船 %s 船 %s 泊位 %s 满足约束(2.2) " % (v1, v2, b))  # 约束（3.2）
                    if (vessel[v1][1] >= vessel[v2][1]) and (vessel[v2][2] >= vessel[v1][1]):
                        model_level1.addConstr(yvb[v1, b]+yvb[v2, b]<=1,name="约束(2.3)：船 %s 船 %s 泊位 %s 满足约束(2.2) " % (v1, v2, b))
#                        model_level1.addConstr(yvb[v1, b] * yvb[v2, b] == 0,
#                                               name="约束(2.3)：船 %s 船 %s 泊位 %s 满足约束(2.2) " % (v1, v2, b))  # # 约束（3.3）

    # 约束(3)表示每一个中转箱必须从泊位到箱区（卸船到泊位后方的卸船箱区），以及从箱区（箱区后方的装船箱区）到泊位（装船）
    for v in vessel.keys():  # 卸船到泊位对应的卸船箱区
        if c1v[v] == []:
            continue
        for b in berth.keys():
            for c in c1v[v]:
                # model_level1.addConstr(yvb[v, b] == U.sum(c, b, mb[b][1]), name="约束（3.1）")
                # model_level1.addConstr(yvb[v, b] == U.sum(c, b, '*'), name="约束（3.1）")
                inde = [0,1]
                index1 = inde.pop(random.choice([0,1]))
                index2 = inde[0]
                m1 = mb_xc[b][index1]
                m2 = mb_xc[b][index2]
                model_level1.addConstr(yvb[v, b] == U[c, b, m1], name="约束（3.1）")
                model_level1.addConstr(U[c, b, m2]==0, name="约束（3.1）")
#                m = random.choice(mb_xc[b])
#                model_level1.addConstr(yvb[v, b] == U.sum(c, b, m), name="约束（3.1）")

    for v in vessel.keys():  # 从泊位对应的装船箱区装船
        if c2v[v] == []:
            continue
        for b in berth.keys():
            for c in c2v[v]:
                # model_level1.addConstr(yvb[v, b] == V.sum(c, mb[b][0], b), name="约束（3.2）")
                inde = [0,1]
                index1 = inde.pop(random.choice([0,1]))
                index2 = inde[0]
                m1 = mb_zc[b][index1]
                m2 = mb_zc[b][index2]
                model_level1.addConstr(yvb[v, b] == V[c, m1, b], name="约束（3.2）")
                model_level1.addConstr(V[c, m2, b]==0, name="约束（3.2）")
                #model_level1.addConstr(yvb[v, b] == V.sum(c, '*', b), name="约束（3.2）")
#                m = random.choice(mb_zc[b])
#                model_level1.addConstr(yvb[v, b] == V.sum(c, m, b), name="约束（3.2）")

    # 约束(3)表示每一个中转箱必须从泊位到箱区（卸船），以及从箱区到泊位（装船）
    '''
    for v in vessel.keys(): # 卸船
        if c1v[v] == []:
            continue
        for b in berth.keys():
            for c in c1v[v]:
                model_level1.addConstr( yvb[v,b] == U.sum(c,b,'*'), name="约束（3.1）")

    for v in vessel.keys(): # 装船
        if c2v[v] == []:
            continue
        for b in berth.keys():
            for c in c2v[v]:
                model_level1.addConstr( yvb[v,b] == V.sum(c,'*',b),name="约束（3.2）")
    '''

    ## 设置目标函数
    model_level1.setObjective(0, GRB.MINIMIZE)  # 最小化一个常数，那么可行域的任何一个解均为最优解，目的就是输出所有可行解

    # 获取模型的变量与值
    model_level1.__data = yvb, U, V

    return model_level1