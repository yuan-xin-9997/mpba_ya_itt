# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: tabu_search_for_model_level2.py
@time: 2020/7/25 20:38
"""

"""
输入初始解（Solomon插入算法构造，或自适应并行路径算法AdaptiveParallelRouteConstruction构造）
在初始解的基础上，通过禁忌搜索算法求解PDPTW问题
"""

import numpy as np
import random
import copy
from assistants import cal_model_obj
# random.seed(1)


def tabu_search(init_vehs_route, pd_nodes, tabu_tenure= 20, iter_max=200):
    """禁忌搜索算法
       输入：
         初始解，vehilces，(init_vehs_route)
         禁忌长度(tabu_tenure)，默认值为20
         迭代次数(iter_max)，默认值为200
         最优解不变跳出代数
         p_l：违反载量的权重
         p_t：违反时间窗的权重
    """

    iter_break = 0.2 * iter_max  # 此值表示，如果连续迭代到一定代数，最优解没有变，那么停止算法搜索
    num_pd_nodes = len(pd_nodes)  # 2个depot数量+PD点对的数量

    count_break = 0  # 连续一定代数不改变全局最优解计数
    iteration = 0  # 迭代次数计数
    
    # 禁忌表存储将点c插入到车v的操作对，节点数量x初始解所有的车辆数量
    tabu = np.zeros((num_pd_nodes, len(init_vehs_route)))
    
    # 将初始解赋值为全局最优解
    # 双重潜拷贝(copy)实现深拷贝(deepcopy),提升性能
    global_best_vehs = [copy.copy(init_vehs_route[i]) for i in range(len(init_vehs_route))]
    for i in range(len(init_vehs_route)):
        global_best_vehs[i].pd_route = copy.copy(init_vehs_route[i].pd_route)  # 路径
    global_best_obj = cal_model_obj(init_vehs_route)  # 计算全局最优解的目标函数值（即，计算tabu搜索初始解的最优值）
    
    # 禁忌算法主体
    while iteration < iter_max:  # 迭代次数（iteration）<最大迭代次数（iter_max）

        iteration += 1

        neigbor_best_obj = np.inf  # 当前迭代次数的邻域最优解obj
        neigbor_best_no_tabu_obj = np.inf  # 没被禁忌的邻域最优解obj

        best_cus = np.nan  # 最优的插入顾客编号
        best_cus_no_tabu = np.nan  # 没被禁忌的最优的插入顾客编号
        
        best_veh = np.nan  # 最优的插入车辆编号
        best_veh_no_tabu = np.nan  # 没被禁忌的最优的插入车辆编号

        cur_pos = np.nan  # 每个点在当前车所属位置
        rand = random.randint(0, 10)  # 随机生成一个0-10之间的整数，用于禁忌表使用
        
        # 计算每个pd点对插入每个其他车的所有位置时候的目标函数值（邻域操作），并选中能够是目标函数值减少最多的一个插入操作
        for pd_node in pd_nodes:  # 遍历pd_node的列表
            
            # 寻找pd_node点对在当前车辆路径当中的位置
            for i in init_vehs_route[pd_node.belong_veh].pd_route[1:-1]:
                if i[0] == pd_node.p_id and i[1] == pd_node.d_id:
                    cur_pos = init_vehs_route[pd_node.belong_veh].pd_route.index(i)  # pd点对在其所在车辆路径的位置索引
                    break
            
            # 遍历点pd_node点对以外的每一辆车，选择插入位置
            for k in init_vehs_route: # 遍历现在可行解当中的每辆车
                
                if len(k.route) > 2 and pd_node.belong_veh != k.v_id:  # 如果车k不是没启用，并且pd_node不属于车k
                    
                    for p in range(1,len(k.pd_route)):  # 遍历车k的除开始depot外的每一个经过的pd点对的索引
                        k.insert_pd_node(pd_node.p_id,pd_node.d_id,p) # 将pd_node插入插入到车k路径中索引p的位置
                        init_vehs_route[pd_node.belong_veh].del_node_by_node(pd_node) # 删除pd点原来的车路径中的pd点对
                        
                        inserted_obj = cal_model_obj(init_vehs_route)  # 计算目标值
                        
                        # 如果插入后的最优解小于当前迭代次数的邻域最优解
                        if inserted_obj < neigbor_best_obj:
                            neigbor_best_obj = inserted_obj
                            best_cus = pd_node
                            best_veh = k.v_id
                            best_pos = p
                            ori_pos = cur_pos
                        
                        # 如果插入后的最优解小于没有被禁忌的邻域最优解，并且，该插入操作禁忌表中的值小于当前迭代次数???（没有被禁忌？？？）
                        if inserted_obj < neigbor_best_no_tabu_obj and tabu[pd_node.pd_id][k.v_id] < iteration:
                            neigbor_best_no_tabu_obj = inserted_obj
                            best_cus_no_tabu = pd_node
                            best_veh_no_tabu = k.v_id
                            best_pos_no_tabu = p
                        
                        # 还原init_vehs_route（在下面才会判断哪个是最优邻域解，这里只是为了获得哪个插入操作是最优的）
                        init_vehs_route[pd_node.belong_veh].insert_pd_node(pd_node.p_id,pd_node.d_id,cur_pos)
                        k.del_node_by_node(pd_node)

        # 将上述邻域插入操作中得到的最好的插入操作，并执行，并判断最优邻域解是否可行，如果不可行，那么回滚该操作（并更新惩罚系数）
        init_vehs_route[best_veh].insert_pd_node(best_cus.p_id,best_cus.d_id,best_pos)  # 插入pd点对
        init_vehs_route[best_cus.belong_veh].del_node_by_node(best_cus) # 删除原pd点对
        feasible_list = []  # 元素为执行上述插入操作后的所有车辆路径是否违背硬时间窗的指示，如果没有违背则为1（True），违背则为0（False）
        for veh in init_vehs_route:# 检查最优邻域解是否可行，并更新惩罚系数
            feasible_list.append(veh.check_vehicle_route_feasible())
        if min(feasible_list) == 0:  # 如果有违背时间窗
            status = False
        else:
            status = True
        
        # 禁忌操作
        if neigbor_best_obj < global_best_obj and status:  # 如果当前的邻域最优解<全局最优解，并且邻域解是可行的（True）

            # 删除长度为2的空路径
            for v in init_vehs_route:
                if len(v.route) <= 2:
                    init_vehs_route.remove(v)  # 如果哪辆车没pd点对了，则将其移除
            global_best_obj = neigbor_best_obj  # 将最优邻域解赋值为全局最优解

            # 双重潜拷贝(copy)实现深拷贝(deepcopy),提升性能
            global_best_vehs = [copy.copy(init_vehs_route[i]) for i in range(len(init_vehs_route))]
            for i in range(len(init_vehs_route)):
                global_best_vehs[i].pd_route = copy.copy(init_vehs_route[i].pd_route)  # 路径

            # 将操作“将pd点对插入到车辆某个位置”加入到禁忌表中，其 禁忌值=迭代次数+tabu_tenure+随机生成的0-10的整数
            tabu[best_cus.pd_id][best_cus.belong_veh] = iteration + tabu_tenure + rand
            
            # 更新被操作的节点所属车编号
            best_cus.belong_veh = best_veh
            
            # 有提升解，则将count_break赋值为0
            count_break = 0

        else:  # 如果邻域最优解没有更好，或邻域最优解是不可行的，或者两者兼有

            # 还原init_vehs_route
            init_vehs_route[best_cus.belong_veh].insert_pd_node(best_cus.p_id,best_cus.d_id,ori_pos)  # 插入到原来的路径当中
            init_vehs_route[best_veh].del_node_by_node(best_cus)  # 将插入的点从新的路径中删除


            # 以未被禁忌的最优邻域解更新init_vehs_route？？？（这么插入，万一是违背时间窗怎么办？？？）
            init_vehs_route[best_veh_no_tabu].insert_pd_node(best_cus_no_tabu.p_id,best_cus_no_tabu.d_id,best_pos_no_tabu)  # 插入pd点对
            init_vehs_route[best_cus_no_tabu.belong_veh].del_node_by_node(best_cus_no_tabu) # 删除原pd点对
            
            # 将操作“将pd点对插入到车辆某个位置”加入到禁忌表中，其 禁忌值=迭代次数+tabu_tenure+随机生成的0-10的整数
            tabu[best_cus_no_tabu.pd_id][best_cus_no_tabu.belong_veh] = iteration + tabu_tenure + rand
            
            # 更新被操作的节点所属车编号
            best_cus_no_tabu.belong_veh = best_veh_no_tabu  
            
            # 解没有提升，则将count_break加1
            count_break += 1


        # 连续一定代数不改变全局最优解，则停止迭代，即停止算法
        if count_break == iter_break:
            break

        # 更新禁忌表
        # tabu = np.where(tabu > 0,tabu-1,tabu)
    
    
    # 更新每个pd点对的所属车编号
    for vehicle in global_best_vehs:
        for i in vehicle.pd_route[1:-1]:  # 遍历车辆veh的路径中除开始depot和结束depot以外的所有pd点对
            for j in pd_nodes:
                if j.p_id == i[0] and j.d_id == i[1]:
                    j.belong_veh = vehicle.v_id  # 在类对象的外部设置对象的属性

    return global_best_vehs, global_best_obj