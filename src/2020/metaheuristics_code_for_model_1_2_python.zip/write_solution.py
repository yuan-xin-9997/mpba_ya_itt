# -*- coding: utf-8 -*-
"""
@author: yuan_xin
@contact: yuanxin9997@qq.com
@file: write_solution.py
@time: 2020/7/25 20:28
"""

from gurobipy import GRB
import random

# （由于可行分配方案过大，这一步，以一定规则选择性的将可行解写入文件中）
def write_level1_solution(vessel, container, berth, mb_zc,mb_xc, model_level1, nSolutions, yvb, U, V):
    """  写入文件.

    具体描述：将第一阶段模型的所有可行解写入到文件当中.
    """
    # 小型instance100次？中型instance200次？大型instance300次？
    solu_number_list = random.sample(range(nSolutions),300) # 固定为每种规模的instance，都只计算1000次（这种方式待定，到规模比较大的时候，1000次也非常庞大）
    solu_number_list.sort()  # 从小到大排序
    
    # 为了使程序运行更快，以下这些信息不用被写入
    
    #for i in range(nSolutions):
    for i in solu_number_list:
        model_level1.setParam(GRB.Param.SolutionNumber, i)
        DataPath_oflevel1solution = "./level1_solution/leve1_solution_%s.txt" % i
        f = open(DataPath_oflevel1solution, 'w')
        
        f.write(str('--------------第 %s 个可行解的目标函数值与决策变量值（泊位分配+箱区选位）-------------' % i))
        f.write('\n')
        f.write(str('--目标函数值--：%f' % model_level1.PoolObjVal))
        f.write('\n')
        f.write('--决策变量值--')
        f.write('\n')
        f.write('-船舶靠泊决策-')
        f.write('\n')
        for v in vessel.keys():
            for b in berth.keys():
                if yvb[v, b].xn > .9:
                    f.write(str('船 %s 靠泊 泊位 %s' % (v, b)))
                    f.write('\n')
            # for c in container.keys():
            # if ycb[c,b].xn > .9:
            # print('中转箱 %s 靠泊 泊位 %s' % (c,b))
        f.write('-中转箱卸船时泊位到箱区决策-')
        f.write('\n')
        for c in container.keys():
            for b in berth.keys():
                for m in mb_xc[b]:
                #m = mb[b][1]
                    if U[c, b, m].xn > .9:
                        f.write(str('中转箱 %s 从 泊位 %s 卸船到 箱区 %s' % (c, b, m)))
                        f.write('\n')
        f.write('-中转箱装船时箱区到泊位决策-')
        f.write('\n')
        for c in container.keys():
            for b in berth.keys():
                for m in mb_zc[b]:
                #m = mb[b][0]
                    if V[c, m, b].xn > .9:
                        f.write(str('中转箱 %s 从 箱区 %s 装船到 泊位 %s' % (c, m, b)))
                        f.write('\n')
        f.close()
    
        
    return solu_number_list,len(solu_number_list)